<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>
<head lang="en">
    <meta charset="UTF-8">
    <script src="/12366/www.12366.ha.cn/Application/Home/Common/js/jquery-1.4.3.min.js"></script>
    <style type="text/css">
        .operation { height: 59px;border: solid 0px #ccc;  background: #1a54a6 url('/12366/www.12366.ha.cn/Application/Home/Common/icon/kuangjia.jpg') no-repeat;}
        .userinfo {background-color: #2da1e6; text-align: left; padding: 7px 0px 8px 10px; background:url('/12366/www.12366.ha.cn/Application/Home/Common/icon/top-line.png');}
        .table-link {width: 340px;border: solid 0px #ccc;height: 40px; float: right; margin-right: 100px; margin-top: 10px;}
        a{font-size: 12px; padding-right: 12px; color: #000000; text-decoration: none;}
        .button-bg{height: 22px; text-align: right;}
        a:hover{text-decoration: underline;}
    </style>
    <script type="text/javascript">
        $(document).ready(function(){
            $('#d-name').dblclick(function(){
                var value = $(this).text();
                $(this).html('<input id="input-name" type="text" value="'+value+'"/>');
                $('#input-name').focus();
                $('#input-name').blur(function () {
                    var name = $('#input-name').val()
                    $('#d-name').html($('#input-name').val());
                    $.post("/12366/www.12366.ha.cn/index.php/Home/Default/save_name", {name: name}, function (data) {
                    },'json');
                });
            });
        });
    </script>
</head>

<body style="margin: 0; padding: 0;">
<div class="operation">
    <div style="width: 500px; background: url('/12366/www.12366.ha.cn/Application/Home/Common/icon/close-bg.gif') no-repeat right top; display: inline-block; float: right; border: solid 0px #ccc;">
        <table class="table-link">
            <tr>
                <td>
                    <div class="button-bg" style="width: 118px; background: url('/12366/www.12366.ha.cn/Application/Home/Common/icon/modify-button.png') no-repeat;">
                        <a href="#" >修改注册信息</a>
                    </div>
                </td>
                <td id="td2">
                    <div class="button-bg" style="width: 94px; background: url('/12366/www.12366.ha.cn/Application/Home/Common/icon/kouling.png') no-repeat;">
                        <a href="#" style="width:100px">修改口令</a>
                    </div>
                </td>
                <td id="td3" >
                    <div class="button-bg" style="width: 94px; background: url('/12366/www.12366.ha.cn/Application/Home/Common/icon/quit-button.png') no-repeat">
                        <a href="#" style="width: 100px;">退出登录</a>
                    </div>
                </td>
            </tr>
        </table>
    </div>
</div>
<div class="userinfo">
    <b style="font-size: 12px; color: #fff;">登陆用户［<b id="d-name"><?php echo ((isset($web_name) && ($web_name !== ""))?($web_name):"河南起重机器有限公司"); ?></b>］</b>
</div>
</body>

</html>