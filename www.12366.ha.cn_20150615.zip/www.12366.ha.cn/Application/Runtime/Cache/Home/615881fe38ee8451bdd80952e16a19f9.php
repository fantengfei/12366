<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>
	<head>
		<title>html</title>
		<meta http-equiv="content-type" content="text/html charset=utf8">
		<link rel="stylesheet" type="text/css" href="/12366/www.12366.ha.cn/Application/Home/Common/css/table.css" media="all">
		<script src="/12366/www.12366.ha.cn/Application/Home/Common/js/jquery-1.4.3.min.js"></script>

        <script src="/12366/www.12366.ha.cn/Public/ext/ext-all.js"></script>
<!--<script src="/12366/www.12366.ha.cn/Public/ext/bootstrap.js"></script>-->
<script src="/12366/www.12366.ha.cn/Public/ext/packages/ext-locale/build/ext-locale-zh_CN.js"></script>
<link href="/12366/www.12366.ha.cn/Public/ext/packages/ext-theme-classic/build/resources/ext-theme-classic-all.css" rel="stylesheet" />
<!--<link href="/12366/www.12366.ha.cn/Public/ext/packages/ext-theme-neptune/build/resources/ext-theme-neptune-all.css" rel="stylesheet" />-->
<!--<link href="/12366/www.12366.ha.cn/Public/ext/packages/ext-theme-gray/build/resources/ext-theme-gray-all.css" rel="stylesheet" />-->
<script type="text/javascript">

    /**
     * 选项池，
     *
     * 标准字段有：‘保存，删除，打印预览，提取数据，修改本年累计’
     *
     * 应用范例：
     *
     * <\include file="./Application/Home/Common/html/toolbar.html" />
     * <\script type="text/javascript">
     *       Ext.onReady(function(){
     *           var option = ['保存','-' ,'删除'];
     *          createOptions(option);
     *       });
     * <\/script>
     *
     * */

    var option = [{
        xtype: 'button', // default for Toolbars
        text: '保存',
        icon: '/12366/www.12366.ha.cn/Application/Home/Common/icon/save-icon.png',
        listeners: {
            click: {
                fn: function() {

                    var table_data = Ext.get('bodydiv').getHtml();
                    var root_name  = $('#root_name').val();
                    var table_name = $('#table_name').val();
                    var table_type = $('#table_type').val();
                    var table_url  = $('#table_url').val();


//                    var win = Ext.create("Ext.window.Window", {
//                        id: "myWin",
//                        title: "保存",
//                        width: 400,
//                        height: 200,
//                        layout: "fit",
//                        items: [
//                            {
//                                xtype: 'datefield',
//                                id: 'save_time',
//                                width: 100,
//                                fieldLabel: '保存时间',
//                                name: 'to_date',
//                                format: 'Y-m-d',
//                                editable: false,
//                                allowBlank: false,
//                                value: new Date()
//                            }
//                        ],
//                        buttons: [
//                            { xtype: "button", text: "确定", handler: function () {
//
//                                var currentTime = Ext.util.Format.date(new Date(Ext.getCmp('save_time').getValue()), 'Y-m-d');
//
//                                Ext.Ajax.request({
//                                    url: '/12366/www.12366.ha.cn/index.php/Home/Index/save_table',
//                                    params: {
//                                        table_data:table_data,
//                                        root_name :root_name,
//                                        table_name:table_name,
//                                        table_type:table_type,
//                                        table_url :table_url,
//                                        save_time: currentTime
//                                    },
//                                    success: function(response){
//                                        var text = response.responseText;
//                                        if(text == 'success'){
//                                            alert("成功！");
//                                        }else{
//                                            alert("失败！");
//                                        }
//
//                                        win.close();
//                                    }
//                                });
//
//
//                            } },
//                            { xtype: "button", text: "取消", handler: function () { this.up("window").close(); } }
//                        ]
//                    });
//
//                    win.show();
                    var win = Ext.create("Ext.window.Window", {
                        id: "myWin",
                        title: "保存",
                        width: 500,
                        height: 100,
                        layout: "fit",
                        items: [
                            {
                                xtype: "form",
                                defaultType: 'textfield',
                                defaults: {
                                    anchor: '100%'
                                },
                                fieldDefaults: {
                                    labelWidth: 80,
                                    labelAlign: "left",
                                    flex: 1,
                                    margin: 5
                                },
                                items: [
                                    {
                                        xtype: "container",
                                        layout: "hbox",
                                        items: [
                                            {
                                                xtype: 'datefield',
                                                id: 'save_time',
                                                width: 100,
                                                fieldLabel: '保存时间',
                                                name: 'to_date',
                                                format: 'Y-m-d',
                                                editable: false,
                                                allowBlank: false,
                                                value: new Date()
                                            }
                                        ]
                                    }
                                ]
                            }
                        ],
                        buttons: [
                            { xtype: "button", text: "确定", handler: function () {

                                var isShow = 1;

                                if (!confirm("是否在查询打印里显示？")) {
                                    isShow = 0;
                                }
                                var currentTime = Ext.util.Format.date(new Date(Ext.getCmp('save_time').getValue()), 'Y-m-d');
                                Ext.Ajax.request({
                                    url: '/12366/www.12366.ha.cn/index.php/Home/Index/save_table',
                                    params: {
                                        table_data:table_data,
                                        root_name :root_name,
                                        table_name:table_name,
                                        table_type:table_type,
                                        table_url :table_url,
                                        save_time: currentTime,
                                        is_show: isShow
                                    },
                                    success: function(response){
                                        var text = response.responseText;
                                        if(text == 'success'){
                                            alert("成功！");
                                        }else{
                                            alert("失败！");
                                        }

                                        win.close();
                                    }
                                });
                            } },
                            { xtype: "button", text: "取消", handler: function () { this.up("window").close(); } }
                        ]
                    });

                    win.show();

                }
            }
        }
    },'-', {
        xtype: 'button',
        text : '删除',
        icon: '/12366/www.12366.ha.cn/Application/Home/Common/icon/return.png'
    },'-', {
        xtype:'button',
        text: '打印预览',
        icon: '/12366/www.12366.ha.cn/Application/Home/Common/icon/yulandayin.png'
    },'-', {
        xtype: 'button',
        text: '提取数据',
        icon:'/12366/www.12366.ha.cn/Application/Home/Common/icon/xuanzhuan.png'
    },'-',{
        xtype: 'checkbox',
        boxLabel: '修改本年累计'
    },'->', {
        xtype: 'button',
        icon: '/12366/www.12366.ha.cn/Application/Home/Common/icon/help.jpg'
    }];

    function save() {

    }

    function createOptions(item) {

        var items = [];

        if (item == null) {
            items = option;
        } else {
            for (var j=0; j< item.length; j++) {
                if (item[j] == '-') {
                    items.push('-');
                    continue;
                }
                for (var i=0; i< option.length; i++) {
                    if (item[j] == option[i].text) {
                        items.push(option[i]);
                        break;
                    }
                }
            }
        }

        Ext.create('Ext.toolbar.Toolbar', {
            renderTo: 'tool-bar',
            border: false,
            items: items
        });
    }

    Ext.onReady(function(){

        // 设置 ‘bodydiv’ 元素的 style
        Ext.get('bodydiv').setHeight(document.documentElement.clientHeight - 28);
        Ext.fly('bodydiv').setStyle({
            border: 'solid 1px #000000',
            overflow:'auto'
        });
    });
</script>

        <script type="text/javascript">
            Ext.onReady(function(){
                createOptions();
            });
        </script>

		<style>
            .icon .divimage{
                background-image:url('/12366/www.12366.ha.cn/Application/Home/Common/image/trigon.png') ;
            }

		</style>
	</head>
	<body id="body-base" style="background-color: #ede6d7;">
        <div id="tool-bar"></div>
		<div id= 'bodydiv'>
            
<input type='hidden' id="table_url" value="<?php echo ($table_url); ?>">
<input type='hidden' id="root_name" value="居民企业所得税2014（年报A）">
<input type='hidden' id="table_name" value="职工薪酬纳税调整明细表">
<input type='hidden' id="table_type" value="2">
<table id="bodytable" width="819px;">
<tr class='titletr title-notic'>
    <td colspan = '8' id='titletd'>职工薪酬纳税调整明细表</td>
</tr>
<tr class='titletr'>
    <td colspan = '8'>&nbsp;</td>
</tr>
<tr class='titletr'>
    <td colspan = '8'>&nbsp;</td>
</tr>
<tr class='titletr'>
    <td colspan = '8'>税款所属期：2015年02月01日至2015年02月28日</td>
</tr>
<tr class='titletr'>
    <td colspan = '8'>纳税人名称：河南起重机械有限公司</td>
</tr>
<tr class='titletr'>
    <td colspan = '5'>纳税人识别号：410711775106396</td>
    <td class = 'text-right' colspan="3" >金额单位：元（列至角至分）</td>
</tr>

<tr>
    <td class="gauge-style text-center" width="30px" rowspan="2">行次</td>
    <td class="gauge-style text-center" width="300px" rowspan="2">项目</td>
    <td class="gauge-style text-center" width="80px">账载金额</td>
    <td class="gauge-style text-center" width="80px">税收规定扣除率</td>
    <td class="gauge-style text-center" width="80px;">以前年度累计结转扣除额</td>
    <td class="gauge-style text-center" width="80px;">税收金额</td>
    <td class="gauge-style text-center" width="80px;">纳税调整金额</td>
    <td class="gauge-style text-center" width="80px;">累计结转以后年度扣除额</td>
</tr>
<tr>
    <td class="gauge-style text-center">1</td>
    <td class="gauge-style text-center">2</td>
    <td class="gauge-style text-center">3</td>
    <td class="gauge-style text-center">4</td>
    <td class="gauge-style text-center">5</td>
    <td class="gauge-style text-center">6</td>
</tr>
<tr>
    <td class="gauge-style text-center">1</td>
    <td class="gauge-style text-left">一、工资薪金支出</td>
    <td class="text-right">0.00</td>
    <td class="text-right">*</td>
    <td class="text-right">*</td>
    <td class="text-right">0.00</td>
    <td class="text-right gray">0.00</td>
    <td class="text-right">*</td>
</tr>
<tr>
    <td class="gauge-style text-center">2</td>
    <td class="gauge-style text-left">&emsp;&emsp;其中：股权激励</td>
    <td class="text-right">0.00</td>
    <td class="text-right">*</td>
    <td class="text-right">*</td>
    <td class="text-right">0.00</td>
    <td class="text-right gray">0.00</td>
    <td class="text-right">*</td>
</tr>
<tr>
    <td class="gauge-style text-center">3</td>
    <td class="gauge-style text-left">二、职工福利费支出</td>
    <td class="text-right">0.00</td>
    <td class="text-right gray">0.00</td>
    <td class="text-right">*</td>
    <td class="text-right">0.00</td>
    <td class="text-right gray">0.00</td>
    <td class="text-right">*</td>
</tr>
<tr>
    <td class="gauge-style text-center">4</td>
    <td class="gauge-style text-left">三、职工教育经费支出</td>
    <td class="text-right gray">0.00</td>
    <td class="text-right gray">*</td>
    <td class="text-right gray">0.00</td>
    <td class="text-right gray">0.00</td>
    <td class="text-right gray">0.00</td>
    <td class="text-right gray">0.00</td>
</tr>
<tr>
    <td class="gauge-style text-center">5</td>
    <td class="gauge-style text-left">&emsp;&emsp;其中：按税收规定比例扣除的职工教育经费</td>
    <td class="text-right">0.00</td>
    <td class="text-right gray">*</td>
    <td class="text-right">0.00</td>
    <td class="text-right">*</td>
    <td class="text-right gray">*</td>
    <td class="text-right gray">*</td>
</tr>
<tr>
    <td class="gauge-style text-center">6</td>
    <td class="gauge-style text-left">&emsp;&emsp;&emsp;&emsp;&emsp;按税收规定全额扣除的职工培训费用</td>
    <td class="text-right">0.00</td>
    <td class="text-right gray">0.00</td>
    <td class="text-right">0.00</td>
    <td class="text-right">0.00</td>
    <td class="text-right gray">0.00</td>
    <td class="text-right">0.00</td>
</tr>
<tr>
    <td class="gauge-style text-center">7</td>
    <td class="gauge-style text-left">四、公费经费支出</td>
    <td class="text-right">0.00</td>
    <td class="text-right gray">*</td>
    <td class="text-right">0.00</td>
    <td class="text-right">*</td>
    <td class="text-right gray">*</td>
    <td class="text-right">*</td>
</tr>
<tr>
    <td class="gauge-style text-center">8</td>
    <td class="gauge-style text-left">五、各类基本社会保障性交款</td>
    <td class="text-right">0.00</td>
    <td class="text-right">*</td>
    <td class="text-right">0.00</td>
    <td class="text-right">*</td>
    <td class="text-right gray">*</td>
    <td class="text-right">*</td>
</tr>
<tr>
    <td class="gauge-style text-center">9</td>
    <td class="gauge-style text-left">六、住房公积金</td>
    <td class="text-right">0.00</td>
    <td class="text-right">*</td>
    <td class="text-right">0.00</td>
    <td class="text-right">*</td>
    <td class="text-right gray">*</td>
    <td class="text-right">*</td>
</tr>
<tr>
    <td class="gauge-style text-center">10</td>
    <td class="gauge-style text-left">七、补充养老保险</td>
    <td class="text-right">0.00</td>
    <td class="text-right gray">*</td>
    <td class="text-right">0.00</td>
    <td class="text-right">*</td>
    <td class="text-right gray">*</td>
    <td class="text-right">*</td>
</tr>
<tr>
    <td class="gauge-style text-center">11</td>
    <td class="gauge-style text-left">八、补充医疗保险</td>
    <td class="text-right">0.00</td>
    <td class="text-right gray">0.00</td>
    <td class="text-right">0.00</td>
    <td class="text-right">0.00</td>
    <td class="text-right gray">*</td>
    <td class="text-right">*</td>
</tr>
<tr>
    <td class="gauge-style text-center">12</td>
    <td class="gauge-style text-left">九、其他</td>
    <td class="text-right">0.00</td>
    <td class="text-right">*</td>
    <td class="text-right">0.00</td>
    <td class="text-right">*</td>
    <td class="text-right gray">*</td>
    <td class="text-right">*</td>
</tr>
<tr>
    <td class="gauge-style text-center">13</td>
    <td class="gauge-style text-left">合计（1+3+4+7+8+9+10+11+12）</td>
    <td class="text-right gray">0.00</td>
    <td class="text-right">*</td>
    <td class="text-right gray">0.00</td>
    <td class="text-right gray">*</td>
    <td class="text-right gray">*</td>
    <td class="text-right gray">*</td>
</tr>

</table>

		</div>
	</body>
	<script src="/12366/www.12366.ha.cn/Application/Home/Common/js/table.js"></script>
</html>