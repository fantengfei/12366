<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>
	<head>
		<title>html</title>
		<meta http-equiv="content-type" content="text/html charset=utf8">
		<link rel="stylesheet" type="text/css" href="/12366/www.12366.ha.cn/Application/Home/Common/css/table.css" media="all">
		<script src="/12366/www.12366.ha.cn/Application/Home/Common/js/jquery-1.4.3.min.js"></script>

        <script src="/12366/www.12366.ha.cn/Public/ext/ext-all.js"></script>
<!--<script src="/12366/www.12366.ha.cn/Public/ext/bootstrap.js"></script>-->
<script src="/12366/www.12366.ha.cn/Public/ext/packages/ext-locale/build/ext-locale-zh_CN.js"></script>
<link href="/12366/www.12366.ha.cn/Public/ext/packages/ext-theme-classic/build/resources/ext-theme-classic-all.css" rel="stylesheet" />
<!--<link href="/12366/www.12366.ha.cn/Public/ext/packages/ext-theme-neptune/build/resources/ext-theme-neptune-all.css" rel="stylesheet" />-->
<!--<link href="/12366/www.12366.ha.cn/Public/ext/packages/ext-theme-gray/build/resources/ext-theme-gray-all.css" rel="stylesheet" />-->
<script type="text/javascript">

    /**
     * 选项池，
     *
     * 标准字段有：‘保存，删除，打印预览，提取数据，修改本年累计’
     *
     * 应用范例：
     *
     * <\include file="./Application/Home/Common/html/toolbar.html" />
     * <\script type="text/javascript">
     *       Ext.onReady(function(){
     *           var option = ['保存','-' ,'删除'];
     *          createOptions(option);
     *       });
     * <\/script>
     *
     * */

    var option = [{
        xtype: 'button', // default for Toolbars
        text: '保存',
        icon: '/12366/www.12366.ha.cn/Application/Home/Common/icon/save-icon.png',
        listeners: {
            click: {
                fn: function() {

                    var table_data = Ext.get('bodydiv').getHtml();
                    var root_name  = $('#root_name').val();
                    var table_name = $('#table_name').val();
                    var table_type = $('#table_type').val();
                    var table_url  = $('#table_url').val();


//                    var win = Ext.create("Ext.window.Window", {
//                        id: "myWin",
//                        title: "保存",
//                        width: 400,
//                        height: 200,
//                        layout: "fit",
//                        items: [
//                            {
//                                xtype: 'datefield',
//                                id: 'save_time',
//                                width: 100,
//                                fieldLabel: '保存时间',
//                                name: 'to_date',
//                                format: 'Y-m-d',
//                                editable: false,
//                                allowBlank: false,
//                                value: new Date()
//                            }
//                        ],
//                        buttons: [
//                            { xtype: "button", text: "确定", handler: function () {
//
//                                var currentTime = Ext.util.Format.date(new Date(Ext.getCmp('save_time').getValue()), 'Y-m-d');
//
//                                Ext.Ajax.request({
//                                    url: '/12366/www.12366.ha.cn/index.php/Home/Index/save_table',
//                                    params: {
//                                        table_data:table_data,
//                                        root_name :root_name,
//                                        table_name:table_name,
//                                        table_type:table_type,
//                                        table_url :table_url,
//                                        save_time: currentTime
//                                    },
//                                    success: function(response){
//                                        var text = response.responseText;
//                                        if(text == 'success'){
//                                            alert("成功！");
//                                        }else{
//                                            alert("失败！");
//                                        }
//
//                                        win.close();
//                                    }
//                                });
//
//
//                            } },
//                            { xtype: "button", text: "取消", handler: function () { this.up("window").close(); } }
//                        ]
//                    });
//
//                    win.show();
                    var win = Ext.create("Ext.window.Window", {
                        id: "myWin",
                        title: "保存",
                        width: 500,
                        height: 100,
                        layout: "fit",
                        items: [
                            {
                                xtype: "form",
                                defaultType: 'textfield',
                                defaults: {
                                    anchor: '100%'
                                },
                                fieldDefaults: {
                                    labelWidth: 80,
                                    labelAlign: "left",
                                    flex: 1,
                                    margin: 5
                                },
                                items: [
                                    {
                                        xtype: "container",
                                        layout: "hbox",
                                        items: [
                                            {
                                                xtype: 'datefield',
                                                id: 'save_time',
                                                width: 100,
                                                fieldLabel: '保存时间',
                                                name: 'to_date',
                                                format: 'Y-m-d',
                                                editable: false,
                                                allowBlank: false,
                                                value: new Date()
                                            }
                                        ]
                                    }
                                ]
                            }
                        ],
                        buttons: [
                            { xtype: "button", text: "确定", handler: function () {

                                var isShow = 1;

                                if (!confirm("是否在查询打印里显示？")) {
                                    isShow = 0;
                                }
                                var currentTime = Ext.util.Format.date(new Date(Ext.getCmp('save_time').getValue()), 'Y-m-d');
                                Ext.Ajax.request({
                                    url: '/12366/www.12366.ha.cn/index.php/Home/Index/save_table',
                                    params: {
                                        table_data:table_data,
                                        root_name :root_name,
                                        table_name:table_name,
                                        table_type:table_type,
                                        table_url :table_url,
                                        save_time: currentTime,
                                        is_show: isShow
                                    },
                                    success: function(response){
                                        var text = response.responseText;
                                        if(text == 'success'){
                                            alert("成功！");
                                        }else{
                                            alert("失败！");
                                        }

                                        win.close();
                                    }
                                });
                            } },
                            { xtype: "button", text: "取消", handler: function () { this.up("window").close(); } }
                        ]
                    });

                    win.show();

                }
            }
        }
    },'-', {
        xtype: 'button',
        text : '删除',
        icon: '/12366/www.12366.ha.cn/Application/Home/Common/icon/return.png'
    },'-', {
        xtype:'button',
        text: '打印预览',
        icon: '/12366/www.12366.ha.cn/Application/Home/Common/icon/yulandayin.png'
    },'-', {
        xtype: 'button',
        text: '提取数据',
        icon:'/12366/www.12366.ha.cn/Application/Home/Common/icon/xuanzhuan.png'
    },'-',{
        xtype: 'checkbox',
        boxLabel: '修改本年累计'
    },'->', {
        xtype: 'button',
        icon: '/12366/www.12366.ha.cn/Application/Home/Common/icon/help.jpg'
    }];

    function save() {

    }

    function createOptions(item) {

        var items = [];

        if (item == null) {
            items = option;
        } else {
            for (var j=0; j< item.length; j++) {
                if (item[j] == '-') {
                    items.push('-');
                    continue;
                }
                for (var i=0; i< option.length; i++) {
                    if (item[j] == option[i].text) {
                        items.push(option[i]);
                        break;
                    }
                }
            }
        }

        Ext.create('Ext.toolbar.Toolbar', {
            renderTo: 'tool-bar',
            border: false,
            items: items
        });
    }

    Ext.onReady(function(){

        // 设置 ‘bodydiv’ 元素的 style
        Ext.get('bodydiv').setHeight(document.documentElement.clientHeight - 28);
        Ext.fly('bodydiv').setStyle({
            border: 'solid 1px #000000',
            overflow:'auto'
        });
    });
</script>

        <script type="text/javascript">
            Ext.onReady(function(){
                createOptions();
            });
        </script>

		<style>
            .icon .divimage{
                background-image:url('/12366/www.12366.ha.cn/Application/Home/Common/image/trigon.png') ;
            }

		</style>
	</head>
	<body id="body-base" style="background-color: #ede6d7;">
        <div id="tool-bar"></div>
		<div id= 'bodydiv'>
            
<input type='hidden' id="table_url" value="<?php echo ($table_url); ?>">
<input type='hidden' id="root_name" value="居民企业所得税2014（年报A）">
<input type='hidden' id="table_name" value="企业所得税年度纳税申报表填报表单">
<input type='hidden' id="table_type" value="2">
<table id="bodytable" width="592px;">
    <tr class='titletr title-notic'>
        <td colspan = '3' id='titletd'>企业所得税年度纳税申报表填报表单</td>
    </tr>
    <tr class="titletr title-notic">
        <td colspan="3">&nbsp;</td>
    </tr>
    <tr class='titletr title-notic'>
        <td colspan = '3' class='font-weight' style="color: red;" >如享受小型微利企业减免优惠，请勾选附表A107040<br/>组织机构类型：企业；行业名称为：电气设备批发；</td>
    </tr>
    <tr class='titletr'>
        <td colspan = '3'>&nbsp;</td>
    </tr>
    <tr class='titletr'>
        <td colspan = '3'>税款所属期：2015年02月01日至2015年02月28日</td>
    </tr>
    <tr class='titletr'>
        <td colspan = '3'>纳税人识别号：410711775106396</td>
    </tr>
    <tr class='titletr'>
        <td colspan = '3'>纳税人名称：新乡市太行橡塑机械有限公司</td>
    </tr>
    <tr>
        <td class="gauge-style text-center" rowspan="2" width="80px"></td>
        <td class="gauge-style text-center" rowspan="2" width="400px"></td>
        <td class="gauge-style text-center" width="80px"></td>
    </tr>
    <tr>
        <td class="gauge-style text-center"></td>
    </tr>
    <tr>
        <td class="gauge-style text-center"></td>
        <td class="text-center gauge-style"></td>
        <td class="text-center gauge-style">√</td>
    </tr>
    <tr>
        <td class="gauge-style text-center"></td>
        <td class="text-center gauge-style"></td>
        <td class="text-center gauge-style">√</td>
    </tr>
    <tr>
        <td class="gauge-style text-center"></td>
        <td class="text-center gauge-style"></td>
        <td class="text-left ">
            <input type="checkbox" checked >
        </td>
    </tr>
    <tr>
        <td class="gauge-style text-center"></td>
        <td class="text-center gauge-style"></td>
        <td class="text-left ">
            <input type="checkbox" disabled="true">
        </td>
    </tr>
    <tr>
        <td class="gauge-style text-center"></td>
        <td class="text-center gauge-style"></td>
        <td class="text-left ">
            <input type="checkbox" checked >
        </td>
    </tr>
    <tr>
        <td class="gauge-style text-center"></td>
        <td class="text-center gauge-style"></td>
        <td class="text-left ">
            <input type="checkbox" disabled="true">
        </td>
    </tr>
    <tr>
        <td class="gauge-style text-center"></td>
        <td class="text-center gauge-style"></td>
        <td class="text-left ">
            <input type="checkbox" disabled="true">
        </td>
    </tr>
    <tr>
        <td class="gauge-style text-center"></td>
        <td class="text-center gauge-style"></td>
        <td class="text-left ">
            <input type="checkbox" disabled="true">
        </td>
    </tr>
    <tr>
        <td class="gauge-style text-center"></td>
        <td class="text-center gauge-style"></td>
        <td class="text-left ">
            <input type="checkbox" disabled="true">
        </td>
    </tr>
    <tr>
        <td class="gauge-style text-center"></td>
        <td class="text-center gauge-style"></td>
        <td class="text-left ">
            <input type="checkbox" checked disabled="true">
        </td>
    </tr>
    <tr>
        <td class="gauge-style text-center"></td>
        <td class="text-center gauge-style"></td>
        <td class="text-left ">
            <input type="checkbox" checked disabled="true">
        </td>
    </tr>
    <tr>
        <td class="gauge-style text-center"></td>
        <td class="text-center gauge-style"></td>
        <td class="text-left ">
            <input type="checkbox">
        </td>
    </tr>
    <tr>
        <td class="gauge-style text-center"></td>
        <td class="text-center gauge-style"></td>
        <td class="text-left ">
            <input type="checkbox">
        </td>
    </tr>
    <tr>
        <td class="gauge-style text-center"></td>
        <td class="text-center gauge-style"></td>
        <td class="text-left ">
            <input type="checkbox">
        </td>
    </tr>
    <tr>
        <td class="gauge-style text-center"></td>
        <td class="text-center gauge-style"></td>
        <td class="text-left ">
            <input type="checkbox">
        </td>
    </tr>
    <tr>
        <td class="gauge-style text-center"></td>
        <td class="text-center gauge-style"></td>
        <td class="text-left ">
            <input type="checkbox" disabled="true" checked>
        </td>
    </tr>
    <tr>
        <td class="gauge-style text-center"></td>
        <td class="text-center gauge-style"></td>
        <td class="text-left ">
            <input type="checkbox">
        </td>
    </tr>
    <tr>
        <td class="gauge-style text-center"></td>
        <td class="text-center gauge-style"></td>
        <td class="text-left ">
            <input type="checkbox">
        </td>
    </tr>
    <tr>
        <td class="gauge-style text-center"></td>
        <td class="text-center gauge-style"></td>
        <td class="text-left ">
            <input type="checkbox" checked disabled="true">
        </td>
    </tr>
    <tr>
        <td class="gauge-style text-center"></td>
        <td class="text-center gauge-style"></td>
        <td class="text-left ">
            <input type="checkbox" checked disabled="true">
        </td>
    </tr>
    <tr>
        <td class="gauge-style text-center"></td>
        <td class="text-center gauge-style"></td>
        <td class="text-left ">
            <input type="checkbox" checked disabled="true">
        </td>
    </tr>
    <tr>
        <td class="gauge-style text-center"></td>
        <td class="text-center gauge-style"></td>
        <td class="text-left ">
            <input type="checkbox">
        </td>
    </tr>
    <tr>
        <td class="gauge-style text-center"></td>
        <td class="text-center gauge-style"></td>
        <td class="text-left ">
            <input type="checkbox">
        </td>
    </tr>
    <tr>
        <td class="gauge-style text-center"></td>
        <td class="text-center gauge-style"></td>
        <td class="text-left ">
            <input type="checkbox" checked disabled="true">
        </td>
    </tr>
    <tr>
        <td class="gauge-style text-center"></td>
        <td class="text-center gauge-style"></td>
        <td class="text-left ">
            <input type="checkbox">
        </td>
    </tr>
    <tr>
        <td class="gauge-style text-center"></td>
        <td class="text-center gauge-style"></td>
        <td class="text-left ">
            <input type="checkbox">
        </td>
    </tr>
    <tr>
        <td class="gauge-style text-center"></td>
        <td class="text-center gauge-style"></td>
        <td class="text-left ">
            <input type="checkbox">
        </td>
    </tr>
    <tr>
        <td class="gauge-style text-center"></td>
        <td class="text-center gauge-style"></td>
        <td class="text-left ">
            <input type="checkbox">
        </td>
    </tr>
    <tr>
        <td class="gauge-style text-center"></td>
        <td class="text-center gauge-style"></td>
        <td class="text-left ">
            <input type="checkbox">
        </td>
    </tr>
    <tr>
        <td class="gauge-style text-center"></td>
        <td class="text-center gauge-style"></td>
        <td class="text-left ">
            <input type="checkbox">
        </td>
    </tr>
    <tr>
        <td class="gauge-style text-center"></td>
        <td class="text-center gauge-style"></td>
        <td class="text-left ">
            <input type="checkbox">
        </td>
    </tr>
    <tr>
        <td class="gauge-style text-center"></td>
        <td class="text-center gauge-style"></td>
        <td class="text-left ">
            <input type="checkbox">
        </td>
    </tr>
    <tr>
        <td class="gauge-style text-center"></td>
        <td class="text-center gauge-style"></td>
        <td class="text-left ">
            <input type="checkbox">
        </td>
    </tr>
    <tr>
        <td class="gauge-style text-center"></td>
        <td class="text-center gauge-style"></td>
        <td class="text-left ">
            <input type="checkbox">
        </td>
    </tr>
    <tr>
        <td class="gauge-style text-center"></td>
        <td class="text-center gauge-style"></td>
        <td class="text-left ">
            <input type="checkbox">
        </td>
    </tr>
    <tr>
        <td class="gauge-style text-center"></td>
        <td class="text-center gauge-style"></td>
        <td class="text-left ">
            <input type="checkbox">
        </td>
    </tr>
    <tr>
        <td class="gauge-style text-center"></td>
        <td class="text-center gauge-style"></td>
        <td class="text-left ">
            <input type="checkbox">
        </td>
    </tr>
    <tr>
        <td class="gauge-style text-center"></td>
        <td class="text-center gauge-style"></td>
        <td class="text-left ">
            <input type="checkbox">
        </td>
    </tr>
    <tr>
        <td class="gauge-style text-center"></td>
        <td class="text-center gauge-style"></td>
        <td class="text-left ">
            <input type="checkbox">
        </td>
    </tr>
    <tr>
        <td class="gauge-style text-center"></td>
        <td class="text-center gauge-style"></td>
        <td class="text-left ">
            <input type="checkbox">
        </td>
    </tr>
    <tr>
        <td class="gauge-style text-center"></td>
        <td class="text-center gauge-style"></td>
        <td class="text-left ">
            <input type="checkbox">
        </td>
    </tr>
    <tr>
        <td class="gauge-style text-center"></td>
        <td class="text-center gauge-style"></td>
        <td class="text-left ">
            <input type="checkbox">
        </td>
    </tr>
    <tr>
        <td class="gauge-style text-center"></td>
        <td class="text-center gauge-style"></td>
        <td class="text-left ">
            <input type="checkbox">
        </td>
    </tr>
    <tr>
        <td class="gauge-style text-center"></td>
        <td class="text-center gauge-style"></td>
        <td class="text-left ">
            <input type="checkbox" disabled="true">
        </td>
    </tr>
    <tr>
        <td class="gauge-style text-center"></td>
        <td class="text-center gauge-style"></td>
        <td class="text-left ">
            <input type="checkbox" disabled="true">
        </td>
    </tr>
    <tr>
        <td class="gauge-style text-center"></td>
        <td class="text-center gauge-style"></td>
        <td class="text-left ">
            <input type="checkbox">
        </td>
    </tr>
    <tr>
        <td class="gauge-style text-left" colspan="3"></td>
    </tr>

</table>

		</div>
	</body>
	<script src="/12366/www.12366.ha.cn/Application/Home/Common/js/table.js"></script>
</html>