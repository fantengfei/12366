<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>
	<head>
		<title>html</title>
		<meta http-equiv="content-type" content="text/html charset=utf8">
		<link rel="stylesheet" type="text/css" href="/12366/www.12366.ha.cn/Application/Home/Common/css/table.css" media="all">
		<script src="/12366/www.12366.ha.cn/Application/Home/Common/js/jquery-1.4.3.min.js"></script>

        <script src="/12366/www.12366.ha.cn/Public/ext/ext-all.js"></script>
<!--<script src="/12366/www.12366.ha.cn/Public/ext/bootstrap.js"></script>-->
<script src="/12366/www.12366.ha.cn/Public/ext/packages/ext-locale/build/ext-locale-zh_CN.js"></script>
<link href="/12366/www.12366.ha.cn/Public/ext/packages/ext-theme-classic/build/resources/ext-theme-classic-all.css" rel="stylesheet" />
<!--<link href="/12366/www.12366.ha.cn/Public/ext/packages/ext-theme-neptune/build/resources/ext-theme-neptune-all.css" rel="stylesheet" />-->
<!--<link href="/12366/www.12366.ha.cn/Public/ext/packages/ext-theme-gray/build/resources/ext-theme-gray-all.css" rel="stylesheet" />-->
<script type="text/javascript">

    /**
     * 选项池，
     *
     * 标准字段有：‘保存，删除，打印预览，提取数据，修改本年累计’
     *
     * 应用范例：
     *
     * <\include file="./Application/Home/Common/html/toolbar.html" />
     * <\script type="text/javascript">
     *       Ext.onReady(function(){
     *           var option = ['保存','-' ,'删除'];
     *          createOptions(option);
     *       });
     * <\/script>
     *
     * */

    var option = [{
        xtype: 'button', // default for Toolbars
        text: '保存',
        icon: '/12366/www.12366.ha.cn/Application/Home/Common/icon/save-icon.png',
        listeners: {
            click: {
                fn: function() {

                    var table_data = Ext.get('bodydiv').getHtml();
                    var root_name  = $('#root_name').val();
                    var table_name = $('#table_name').val();
                    var table_type = $('#table_type').val();
                    var table_url  = $('#table_url').val();


//                    var win = Ext.create("Ext.window.Window", {
//                        id: "myWin",
//                        title: "保存",
//                        width: 400,
//                        height: 200,
//                        layout: "fit",
//                        items: [
//                            {
//                                xtype: 'datefield',
//                                id: 'save_time',
//                                width: 100,
//                                fieldLabel: '保存时间',
//                                name: 'to_date',
//                                format: 'Y-m-d',
//                                editable: false,
//                                allowBlank: false,
//                                value: new Date()
//                            }
//                        ],
//                        buttons: [
//                            { xtype: "button", text: "确定", handler: function () {
//
//                                var currentTime = Ext.util.Format.date(new Date(Ext.getCmp('save_time').getValue()), 'Y-m-d');
//
//                                Ext.Ajax.request({
//                                    url: '/12366/www.12366.ha.cn/index.php/Home/Index/save_table',
//                                    params: {
//                                        table_data:table_data,
//                                        root_name :root_name,
//                                        table_name:table_name,
//                                        table_type:table_type,
//                                        table_url :table_url,
//                                        save_time: currentTime
//                                    },
//                                    success: function(response){
//                                        var text = response.responseText;
//                                        if(text == 'success'){
//                                            alert("成功！");
//                                        }else{
//                                            alert("失败！");
//                                        }
//
//                                        win.close();
//                                    }
//                                });
//
//
//                            } },
//                            { xtype: "button", text: "取消", handler: function () { this.up("window").close(); } }
//                        ]
//                    });
//
//                    win.show();
                    var win = Ext.create("Ext.window.Window", {
                        id: "myWin",
                        title: "保存",
                        width: 500,
                        height: 100,
                        layout: "fit",
                        items: [
                            {
                                xtype: "form",
                                defaultType: 'textfield',
                                defaults: {
                                    anchor: '100%'
                                },
                                fieldDefaults: {
                                    labelWidth: 80,
                                    labelAlign: "left",
                                    flex: 1,
                                    margin: 5
                                },
                                items: [
                                    {
                                        xtype: "container",
                                        layout: "hbox",
                                        items: [
                                            {
                                                xtype: 'datefield',
                                                id: 'save_time',
                                                width: 100,
                                                fieldLabel: '保存时间',
                                                name: 'to_date',
                                                format: 'Y-m-d',
                                                editable: false,
                                                allowBlank: false,
                                                value: new Date()
                                            }
                                        ]
                                    }
                                ]
                            }
                        ],
                        buttons: [
                            { xtype: "button", text: "确定", handler: function () {

                                var isShow = 1;

                                if (!confirm("是否在查询打印里显示？")) {
                                    isShow = 0;
                                }
                                var currentTime = Ext.util.Format.date(new Date(Ext.getCmp('save_time').getValue()), 'Y-m-d');
                                Ext.Ajax.request({
                                    url: '/12366/www.12366.ha.cn/index.php/Home/Index/save_table',
                                    params: {
                                        table_data:table_data,
                                        root_name :root_name,
                                        table_name:table_name,
                                        table_type:table_type,
                                        table_url :table_url,
                                        save_time: currentTime,
                                        is_show: isShow
                                    },
                                    success: function(response){
                                        var text = response.responseText;
                                        if(text == 'success'){
                                            alert("成功！");
                                        }else{
                                            alert("失败！");
                                        }

                                        win.close();
                                    }
                                });
                            } },
                            { xtype: "button", text: "取消", handler: function () { this.up("window").close(); } }
                        ]
                    });

                    win.show();

                }
            }
        }
    },'-', {
        xtype: 'button',
        text : '删除',
        icon: '/12366/www.12366.ha.cn/Application/Home/Common/icon/return.png'
    },'-', {
        xtype:'button',
        text: '打印预览',
        icon: '/12366/www.12366.ha.cn/Application/Home/Common/icon/yulandayin.png'
    },'-', {
        xtype: 'button',
        text: '提取数据',
        icon:'/12366/www.12366.ha.cn/Application/Home/Common/icon/xuanzhuan.png'
    },'-',{
        xtype: 'checkbox',
        boxLabel: '修改本年累计'
    },'->', {
        xtype: 'button',
        icon: '/12366/www.12366.ha.cn/Application/Home/Common/icon/help.jpg'
    }];

    function save() {

    }

    function createOptions(item) {

        var items = [];

        if (item == null) {
            items = option;
        } else {
            for (var j=0; j< item.length; j++) {
                if (item[j] == '-') {
                    items.push('-');
                    continue;
                }
                for (var i=0; i< option.length; i++) {
                    if (item[j] == option[i].text) {
                        items.push(option[i]);
                        break;
                    }
                }
            }
        }

        Ext.create('Ext.toolbar.Toolbar', {
            renderTo: 'tool-bar',
            border: false,
            items: items
        });
    }

    Ext.onReady(function(){

        // 设置 ‘bodydiv’ 元素的 style
        Ext.get('bodydiv').setHeight(document.documentElement.clientHeight - 28);
        Ext.fly('bodydiv').setStyle({
            border: 'solid 1px #000000',
            overflow:'auto'
        });
    });
</script>

        <script type="text/javascript">
            Ext.onReady(function(){
                createOptions();
            });
        </script>

		<style>
            .icon .divimage{
                background-image:url('/12366/www.12366.ha.cn/Application/Home/Common/image/trigon.png') ;
            }

		</style>
	</head>
	<body id="body-base" style="background-color: #ede6d7;">
        <div id="tool-bar"></div>
		<div id= 'bodydiv'>
            
    <input type='hidden' id="table_url" value="<?php echo ($table_url); ?>">
    <input type='hidden' id="root_name" value="居民企业所得税2014（年报A）">
    <input type='hidden' id="table_name" value="职工薪酬纳税调整明细表">
    <input type='hidden' id="table_type" value="2">
    <table id="bodytable" width="734px;">
        <tr class='titletr title-notic'>
            <td colspan = '3' id='titletd'>职工薪酬纳税调整明细表</td>
        </tr>
        <tr class='titletr'>
            <td colspan = '3'>&nbsp;</td>
        </tr>
        <tr class='titletr'>
            <td colspan = '3'>&nbsp;</td>
        </tr>
        <tr class='titletr'>
            <td colspan = '3'>税款所属期：2015年02月01日至2015年02月28日</td>
        </tr>
        <tr class='titletr'>
            <td colspan = '3'>纳税人名称：河南起重机械有限公司</td>
        </tr>
        <tr class='titletr'>
            <td colspan = '2'>纳税人识别号：410711775106396</td>
            <td class = 'text-right' colspan="1" >金额单位：元（列至角至分）</td>
        </tr>

        <tr>
            <td class="gauge-style text-center" width="30px">行次</td>
            <td class="gauge-style text-center" width="500px">项目</td>
            <td class="gauge-style text-center" width="200px">金额</td>
        </tr>
        <tr>
            <td class="gauge-style text-center">1</td>
            <td class="gauge-style text-left">一、本年广告费和业务宣传费支出</td>
            <td class="text-right">0.00</td>
        </tr>
        <tr>
            <td class="gauge-style text-center">2</td>
            <td class="gauge-style text-left">&emsp;&emsp;减：不允许扣除的广告费和业务宣传费支出</td>
            <td class="text-right">0.00</td>
        </tr>
        <tr>
            <td class="gauge-style text-center">3</td>
            <td class="gauge-style text-left">二、本年符合条件的广告费和业务宣传费支出（1-2）</td>
            <td class="text-right gray">0.00</td>
        </tr>
        <tr>
            <td class="gauge-style text-center">4</td>
            <td class="gauge-style text-left">三、本年计算广告费和业务宣传费扣除限额的销售（营业）收入</td>
            <td class="text-right">0.00</td>
        </tr>
        <tr>
            <td class="gauge-style text-center">5</td>
            <td class="gauge-style text-left">&emsp;&emsp;税收规定扣除率</td>
            <td class ='tddata icon'>
                <div class='divimage'></div>
                <div class='divdata'>0.00</div>
            </td>
        </tr>
        <tr>
            <td class="gauge-style text-center">6</td>
            <td class="gauge-style text-left">四、本企业计算的广告费和业务宣传费扣除限额（4x5）</td>
            <td class="text-right gray">0.00</td>
        </tr>
        <tr>
            <td class="gauge-style text-center">7</td>
            <td class="gauge-style text-left">五、本年结转以后年度扣除额（3>6，本行＝3-6，3≦6，本行＝0）</td>
            <td class="text-right gray">0.00</td>
        </tr>
        <tr>
            <td class="gauge-style text-center">8</td>
            <td class="gauge-style text-left">&emsp;&emsp;加：以前年度累计结转扣除额</td>
            <td class="text-right">0.00</td>
        </tr>
        <tr>
            <td class="gauge-style text-center">9</td>
            <td class="gauge-style text-left">&emsp;&emsp;减：本年扣除的以前年度结转额［3>6，本行=0，3≦6，本行＝8或（6-3）孰小值］</td>
            <td class="text-right gray">0.00</td>
        </tr>
        <tr>
            <td class="gauge-style text-center">10</td>
            <td class="gauge-style text-left">六、按照分摊协议归集至其他关联方的广告费和业务宣传费（10 ≦3或6孰小值）</td>
            <td class="text-right">0.00</td>
        </tr>
        <tr>
            <td class="gauge-style text-center">11</td>
            <td class="gauge-style text-left">&emsp;&emsp;按分摊协议从其他关联方归集至本企业的广告费和业务宣传费</td>
            <td class="text-right">0.00</td>
        </tr>
        <tr>
            <td class="gauge-style text-center">12</td>
            <td class="gauge-style text-left">七、本年广告费和业务宣传费支出纳税调整金额（3>6, 本行＝2+3-6+10－11；3 ≦6，本行＝2+10－11-9）</td>
            <td class="text-right gray">0.00</td>
        </tr>
        <tr>
            <td class="gauge-style text-center">13</td>
            <td class="gauge-style text-left">八、累计结转以后年度扣除额（7+8-9）</td>
            <td class="text-right">0.00</td>
        </tr>
    </table>

		</div>
	</body>
	<script src="/12366/www.12366.ha.cn/Application/Home/Common/js/table.js"></script>
</html>