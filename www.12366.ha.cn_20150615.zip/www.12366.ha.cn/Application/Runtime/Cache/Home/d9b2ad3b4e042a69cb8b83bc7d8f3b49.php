<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>
	<head>
		<title>html</title>
		<meta http-equiv="content-type" content="text/html charset=utf8">
		<link rel="stylesheet" type="text/css" href="/12366/www.12366.ha.cn/Application/Home/Common/css/table.css" media="all">
		<script src="/12366/www.12366.ha.cn/Application/Home/Common/js/jquery-1.4.3.min.js"></script>

        <script src="/12366/www.12366.ha.cn/Public/ext/ext-all.js"></script>
<!--<script src="/12366/www.12366.ha.cn/Public/ext/bootstrap.js"></script>-->
<script src="/12366/www.12366.ha.cn/Public/ext/packages/ext-locale/build/ext-locale-zh_CN.js"></script>
<link href="/12366/www.12366.ha.cn/Public/ext/packages/ext-theme-classic/build/resources/ext-theme-classic-all.css" rel="stylesheet" />
<!--<link href="/12366/www.12366.ha.cn/Public/ext/packages/ext-theme-neptune/build/resources/ext-theme-neptune-all.css" rel="stylesheet" />-->
<!--<link href="/12366/www.12366.ha.cn/Public/ext/packages/ext-theme-gray/build/resources/ext-theme-gray-all.css" rel="stylesheet" />-->
<script type="text/javascript">

    /**
     * 选项池，
     *
     * 标准字段有：‘保存，删除，打印预览，提取数据，修改本年累计’
     *
     * 应用范例：
     *
     * <\include file="./Application/Home/Common/html/toolbar.html" />
     * <\script type="text/javascript">
     *       Ext.onReady(function(){
     *           var option = ['保存','-' ,'删除'];
     *          createOptions(option);
     *       });
     * <\/script>
     *
     * */

    var option = [{
        xtype: 'button', // default for Toolbars
        text: '保存',
        icon: '/12366/www.12366.ha.cn/Application/Home/Common/icon/save-icon.png',
        listeners: {
            click: {
                fn: function() {

                    var table_data = Ext.get('bodydiv').getHtml();
                    var root_name  = $('#root_name').val();
                    var table_name = $('#table_name').val();
                    var table_type = $('#table_type').val();
                    var table_url  = $('#table_url').val();


//                    var win = Ext.create("Ext.window.Window", {
//                        id: "myWin",
//                        title: "保存",
//                        width: 400,
//                        height: 200,
//                        layout: "fit",
//                        items: [
//                            {
//                                xtype: 'datefield',
//                                id: 'save_time',
//                                width: 100,
//                                fieldLabel: '保存时间',
//                                name: 'to_date',
//                                format: 'Y-m-d',
//                                editable: false,
//                                allowBlank: false,
//                                value: new Date()
//                            }
//                        ],
//                        buttons: [
//                            { xtype: "button", text: "确定", handler: function () {
//
//                                var currentTime = Ext.util.Format.date(new Date(Ext.getCmp('save_time').getValue()), 'Y-m-d');
//
//                                Ext.Ajax.request({
//                                    url: '/12366/www.12366.ha.cn/index.php/Home/Index/save_table',
//                                    params: {
//                                        table_data:table_data,
//                                        root_name :root_name,
//                                        table_name:table_name,
//                                        table_type:table_type,
//                                        table_url :table_url,
//                                        save_time: currentTime
//                                    },
//                                    success: function(response){
//                                        var text = response.responseText;
//                                        if(text == 'success'){
//                                            alert("成功！");
//                                        }else{
//                                            alert("失败！");
//                                        }
//
//                                        win.close();
//                                    }
//                                });
//
//
//                            } },
//                            { xtype: "button", text: "取消", handler: function () { this.up("window").close(); } }
//                        ]
//                    });
//
//                    win.show();
                    var win = Ext.create("Ext.window.Window", {
                        id: "myWin",
                        title: "保存",
                        width: 500,
                        height: 100,
                        layout: "fit",
                        items: [
                            {
                                xtype: "form",
                                defaultType: 'textfield',
                                defaults: {
                                    anchor: '100%'
                                },
                                fieldDefaults: {
                                    labelWidth: 80,
                                    labelAlign: "left",
                                    flex: 1,
                                    margin: 5
                                },
                                items: [
                                    {
                                        xtype: "container",
                                        layout: "hbox",
                                        items: [
                                            {
                                                xtype: 'datefield',
                                                id: 'save_time',
                                                width: 100,
                                                fieldLabel: '保存时间',
                                                name: 'to_date',
                                                format: 'Y-m-d',
                                                editable: false,
                                                allowBlank: false,
                                                value: new Date()
                                            }
                                        ]
                                    }
                                ]
                            }
                        ],
                        buttons: [
                            { xtype: "button", text: "确定", handler: function () {

                                var isShow = 1;

                                if (!confirm("是否在查询打印里显示？")) {
                                    isShow = 0;
                                }
                                var currentTime = Ext.util.Format.date(new Date(Ext.getCmp('save_time').getValue()), 'Y-m-d');
                                Ext.Ajax.request({
                                    url: '/12366/www.12366.ha.cn/index.php/Home/Index/save_table',
                                    params: {
                                        table_data:table_data,
                                        root_name :root_name,
                                        table_name:table_name,
                                        table_type:table_type,
                                        table_url :table_url,
                                        save_time: currentTime,
                                        is_show: isShow
                                    },
                                    success: function(response){
                                        var text = response.responseText;
                                        if(text == 'success'){
                                            alert("成功！");
                                        }else{
                                            alert("失败！");
                                        }

                                        win.close();
                                    }
                                });
                            } },
                            { xtype: "button", text: "取消", handler: function () { this.up("window").close(); } }
                        ]
                    });

                    win.show();

                }
            }
        }
    },'-', {
        xtype: 'button',
        text : '删除',
        icon: '/12366/www.12366.ha.cn/Application/Home/Common/icon/return.png'
    },'-', {
        xtype:'button',
        text: '打印预览',
        icon: '/12366/www.12366.ha.cn/Application/Home/Common/icon/yulandayin.png'
    },'-', {
        xtype: 'button',
        text: '提取数据',
        icon:'/12366/www.12366.ha.cn/Application/Home/Common/icon/xuanzhuan.png'
    },'-',{
        xtype: 'checkbox',
        boxLabel: '修改本年累计'
    },'->', {
        xtype: 'button',
        icon: '/12366/www.12366.ha.cn/Application/Home/Common/icon/help.jpg'
    }];

    function save() {

    }

    function createOptions(item) {

        var items = [];

        if (item == null) {
            items = option;
        } else {
            for (var j=0; j< item.length; j++) {
                if (item[j] == '-') {
                    items.push('-');
                    continue;
                }
                for (var i=0; i< option.length; i++) {
                    if (item[j] == option[i].text) {
                        items.push(option[i]);
                        break;
                    }
                }
            }
        }

        Ext.create('Ext.toolbar.Toolbar', {
            renderTo: 'tool-bar',
            border: false,
            items: items
        });
    }

    Ext.onReady(function(){

        // 设置 ‘bodydiv’ 元素的 style
        Ext.get('bodydiv').setHeight(document.documentElement.clientHeight - 28);
        Ext.fly('bodydiv').setStyle({
            border: 'solid 1px #000000',
            overflow:'auto'
        });
    });
</script>

        <script type="text/javascript">
            Ext.onReady(function(){
                createOptions();
            });
        </script>

		<style>
            .icon .divimage{
                background-image:url('/12366/www.12366.ha.cn/Application/Home/Common/image/trigon.png') ;
            }

		</style>
	</head>
	<body id="body-base" style="background-color: #ede6d7;">
        <div id="tool-bar"></div>
		<div id= 'bodydiv'>
            
<input type='hidden' id="table_url" value="<?php echo ($table_url); ?>">
<input type='hidden' id="root_name" value="居民企业所得税2014（年报A）">
<input type='hidden' id="table_name" value="企业基础信息表">
<input type='hidden' id="table_type" value="2">
<table id="bodytable" width="850px;">
    <tr class='titletr title-notic'>
        <td colspan = '6' id='titletd'>企业基础信息表</td>
    </tr>
    <tr class="titletr title-notic">
        <td colspan="">&nbsp;</td>
    </tr>
    <tr>
        <td class="text-center gauge-style" colspan="6">100基本信息</td>
    </tr>
    <tr>
        <td class="text-left gauge-style">＊101汇总纳税企业</td>
        <td class="text-left" colspan="5"> &emsp;&emsp;      是（   总机构   <input type="checkbox" disabled="true">   按比例缴纳总机构<input type="checkbox" disabled="true">    ）     否   <input type="checkbox" checked disabled="true"></td>
    </tr>
    <tr>
        <td class="text-left gauge-style">102注册资本（万元）</td>
        <td class="text-center" colspan="2">600.00</td>
        <td class="text-left gauge-style">＊106境外中资控股居民企业</td>
        <td class="text-right" colspan="2">
            是<input type="checkbox">&emsp;&emsp;&emsp;&emsp;否<input type="checkbox" checked>
        </td>
    </tr>
    <tr>
        <td class="text-left gauge-style">103所属行业明细代码</td>
        <td class="text-center" colspan="2">
            <select style="width:100%;" disabled="true">
                <option>电气设备批发</option>
            </select>
        </td>
        <td class="text-left gauge-style">＊107从事国家非限制和禁止行业</td>
        <td class="text-right" colspan="2">
            是<input type="checkbox" >&emsp;&emsp;&emsp;&emsp;否<input type="checkbox" checked >
        </td>
    </tr>
    <tr>
        <td class="text-left gauge-style">
            ＊104从业人数
            </td>
        <td class="text-center" colspan="2">48</td>
        <td class="text-left gauge-style">＊108存在境外关联交易</td>
        <td class="text-right" colspan="2">
            是<input type="checkbox">&emsp;&emsp;&emsp;&emsp;否<input type="checkbox" checked>
        </td>
    </tr>
    <tr>
        <td class="text-left gauge-style">＊105资产总额（万元）</td>
        <td class="text-center" colspan="2">969.22</td>
        <td class="text-left gauge-style">＊109上市公司</td>
        <td class="text-right" colspan="2">
            是（境内<input type="checkbox">&emsp;境外<input type="checkbox">）&emsp;&emsp;&emsp;&emsp;否<input type="checkbox" checked>
        </td>
    </tr>
    <tr>
        <td class="text-center gauge-style" colspan="6">200主要会计政策和估计</td>
    </tr>
    <tr>
        <td class="text-left gauge-style">＊201使用的会计准则或会计制度</td>
        <td class="text-left" colspan="5">
            <p>企业会计准则&emsp;
            一般企业<input type="checkbox" disabled="true">&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;
            银行<input type="checkbox" disabled="true">&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;
            证券<input type="checkbox" disabled="true">&emsp;
            保险<input type="checkbox" disabled="true">&emsp;
            担保<input type="checkbox" disabled="true">&emsp;）</p>
            <p>小企业会计准则&emsp;&emsp;
            <input type="checkbox" disabled="true">&emsp;</p>
            <p>企业会计制度&emsp;&emsp;
            <input type="checkbox" checked></p>
            <p>事业单位会计准则（&emsp;&emsp;&emsp;&emsp;
            事业单位会计制度<input type="checkbox" disabled="true">&emsp;&emsp;&emsp;&emsp;
            科学事业单位会计制度<input type="checkbox" disabled="true">&emsp;&emsp;&emsp;&emsp;</p>
            <p>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&nbsp;医院会计制度<input type="checkbox" disabled="true">
                &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;高等学校会计制度<input type="checkbox" disabled="true">
                &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;中小学会计制度<input type="checkbox" disabled="true"></p>
            <p>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&nbsp;彩票机构会计制度<input type="checkbox" disabled="true"></p>
            <p>民间非营利组织会计制度&emsp;&emsp;
                <input type="checkbox" disabled="true">&emsp;</p>
            <p>村集体经济组织会计制度&emsp;&emsp;
                <input type="checkbox" disabled="true">&emsp;</p>
            <p>农民专业合作社财务会计制度（试行）&emsp;&emsp;
                <input type="checkbox" disabled="true">&emsp;</p>
            <p>其他&emsp;&emsp;
                <input type="checkbox" disabled="true">&emsp;</p>
        </td>
    </tr>
    <tr>
        <td class="gauge-style text-left">＊202会计档案的存放地
            </td>
        <td class=" text-center" colspan="2">财务料</td>
        <td class="gauge-style text-left">203会计核算软件
            </td>
        <td class="text-left" colspan="2">用友U8
            </td>
    </tr>
    <tr>
        <td class="gauge-style text-left">＊204记账本位币
            </td>
        <td class=" text-right" style="border-right: 0px;">人民币<input type="checkbox" checked></td>
        <td class=" text-right" style="border-left: 0px;">其他<input type="checkbox"></td>
        <td class="gauge-style text-left">＊205会计政策和和估计是否发生变化
            </td>
        <td class="text-right" style="border-right: 0px;">是<input type="checkbox"></td>
        <td class="text-right" style="border-left: 0px;">否<input type="checkbox" checked></td>
    </tr>
    <tr>
        <td class="gauge-style text-left">＊206固定资产折旧方法
            </td>
        <td class=" text-right" style="border-right: 0px;">
            年限平均法<input type="checkbox" checked>
        <td class="text-right" style="border-right: 0px; border-left: 0px;">
            工作量法<input type="checkbox"></td>
        <td class=" text-right" style="border-right: 0px; border-left: 0px;">
            双倍余额递减法<input type="checkbox"></td>
        <td class=" text-right" style="border-right: 0px; border-left: 0px;">
            年数总和法<input type="checkbox"></td>
        <td class="text-right" style="border-left: 0px;">
            其他<input type="checkbox"></td>
    </tr>
    <tr>
        <td class="gauge-style text-left" rowspan="2">＊207存货成本计价方法
            </td>
        <td class=" text-right" style="border-right: 0px; border-bottom: 0px;">
            先进先出法<input type="checkbox" >
        <td class="text-right" style="border-right: 0px; border-left: 0px; border-bottom: 0px;">
            移动加权平均法<input type="checkbox"></td>
        <td class=" text-right" style="border-right: 0px; border-left: 0px;border-bottom: 0px;">
            月末一次加权平均法<input type="checkbox" checked></td>
        <td class=" text-right" style="border-right: 0px; border-left: 0px;border-bottom: 0px;">&emsp;</td>
        <td class="text-right" style="border-left: 0px;border-bottom: 0px;"></td>
    </tr>
    <tr>
        <td class=" text-right" style="border-right: 0px; border-top:0px;">
            个别计价法<input type="checkbox" checked>
        <td class="text-right" style="border-right: 0px; border-left: 0px;border-top:0px;">
            毛利率法<input type="checkbox"></td>
        <td class=" text-right" style="border-right: 0px; border-left: 0px;border-top:0px;">
            零售价法<input type="checkbox"></td>
        <td class=" text-right" style="border-right: 0px; border-left: 0px;border-top:0px;">
            计价成本法<input type="checkbox"></td>
        <td class="text-right" style="border-left: 0px;border-top:0px;">
            其他<input type="checkbox"></td>
    </tr>
    <tr>
        <td class="gauge-style text-left">＊208坏账损失核算方法
            </td>
        <td class=" text-right" style="border-right: 0px;">
            备抵法<input type="checkbox">
        <td class="text-right" style="border-right: 0px; border-left: 0px;">
            直接核销法<input type="checkbox" checked></td>
        <td class=" text-right" style="border-right: 0px; border-left: 0px;">&emsp;</td>
        <td class=" text-right" style="border-right: 0px; border-left: 0px;">&emsp;</td>
        <td class="text-right" style="border-left: 0px;">&emsp;</td>
    </tr>
    <tr>
        <td class="gauge-style text-left">＊209所得税计算方法</td>
        <td class=" text-right" style="border-right: 0px;">
            应付税款法<input type="checkbox" checked>
        <td class="text-right" style="border-right: 0px; border-left: 0px;">
        资产负债表债务法<input type="checkbox"></td>
        <td class=" text-right" style="border-right: 0px; border-left: 0px;">
            其他<input type="checkbox"></td>
        <td class=" text-right" style="border-right: 0px; border-left: 0px;">&emsp;</td>
        <td class="text-right" style="border-left: 0px;">&emsp;</td>
    </tr>
    <tr>
        <td class="gauge-style text-center" colspan="6">300企业主要股东及对外投资情况</td>
    </tr>
    <tr>
        <td class="gauge-style text-left" colspan="6">301企业主要股东（前5位）</td>
    </tr>
    <tr>
        <td class="gauge-style text-center">股东名称</td>
        <td class="gauge-style text-center">证件种类</td>
        <td class="gauge-style text-center">证件号码</td>
        <td class="gauge-style text-center">经济性质</td>
        <td class="gauge-style text-center">投资比例</td>
        <td class="gauge-style text-center">国籍（注册地址）</td>
    </tr>
    <tr>
        <td class=" text-left">
            王纪川
        </td>
        <td class=" text-left">
            <select style="width: 100%">
                <option>居民身份证</option>
            </select>
        </td>
        <td class=" text-left">410727196206155633</td>
        <td class=" text-left">
            <select style="width: 100%">
                <option>内资个人</option>
            </select>
        </td>
        <td class=" text-right">100.000000%</td>
        <td class=" text-left">
            <select style="width: 100%">
                <option>中华人民共和国</option>
            </select>
        </td>

    </tr>
    <tr>
        <td class=" text-left"></td>
        <td class=" text-left">
            <select style="width: 100%">
                <option></option>
            </select>
        </td>
        <td class=" text-left"></td>
        <td class=" text-left">
            <select style="width: 100%">
            </select>
        </td>
        <td class=" text-right">0.000000%</td>
        <td class=" text-left">
            <select style="width: 100%">
            </select>
        </td>

    </tr>
    <tr>
        <td class=" text-left"></td>
        <td class=" text-left">
            <select style="width: 100%">
                <option></option>
            </select>
        </td>
        <td class=" text-left"></td>
        <td class=" text-left">
            <select style="width: 100%">
            </select>
        </td>
        <td class=" text-right">0.000000%</td>
        <td class=" text-left">
            <select style="width: 100%">
            </select>
        </td>

    </tr>
    <tr>
        <td class=" text-left"></td>
        <td class=" text-left">
            <select style="width: 100%">
                <option></option>
            </select>
        </td>
        <td class=" text-left"></td>
        <td class=" text-left">
            <select style="width:100%">
            </select>
        </td>
        <td class=" text-right">0.000000%</td>
        <td class=" text-left">
            <select style="width: 100%">
            </select>
        </td>

    </tr>
    <tr>
        <td class=" text-left"></td>
        <td class=" text-left">
            <select style="width: 100%;">
                <option></option>
            </select>
        </td>
        <td class=" text-left"></td>
        <td class=" text-left">
            <select style="width: 100%;">
            </select>
        </td>
        <td class=" text-right">0.000000%</td>
        <td class=" text-left">
            <select style="width: 100%;">
            </select>
        </td>

    </tr>
    <tr>
        <td class="gauge-style text-left" colspan="6">302对外投资（前5位）</td>
    </tr>
    <tr>
        <td class="gauge-style text-center">被投资者名称</td>
        <td class="gauge-style text-center">纳税人识别号</td>
        <td class="gauge-style text-center">经济性质</td>
        <td class="gauge-style text-center">投资比例</td>
        <td class="gauge-style text-center">投资总额</td>
        <td class="gauge-style text-center">注册地址</td>
    </tr>
    <tr>
        <td class=" text-left"></td>
        <td class=" text-left"></td>
        <td class=" text-left">
            <select style="width: 100%; ">
            </select>
        </td>
        <td class=" text-right">0.000000%</td>
        <td class=" text-right">0.00</td>
        <td class="text-left"></td>
    </tr>
    <tr>
        <td class=" text-left"></td>
        <td class=" text-left"></td>
        <td class=" text-left">
            <select style="width:100%;">
            </select>
        </td>
        <td class=" text-right">0.000000%</td>
        <td class=" text-right">0.00</td>
        <td class="text-left"></td>
    </tr>
    <tr>
        <td class=" text-left"></td>
        <td class=" text-left"></td>
        <td class=" text-left">
            <select style="width: 100%;">
            </select>
        </td>
        <td class=" text-right">0.000000%</td>
        <td class=" text-right">0.00</td>
        <td class="text-left"></td>
    </tr>
    <tr>
        <td class=" text-left"></td>
        <td class=" text-left"></td>
        <td class=" text-left">
            <select style="width: 100%;">
            </select>
        </td>
        <td class=" text-right">0.000000%</td>
        <td class=" text-right">0.00</td>
        <td class="text-left"></td>
    </tr>
    <tr>
        <td class=" text-left" width="150px"></td>
        <td class=" text-left" width="150px"></td>
        <td class=" text-left" width="150px">
            <select style="width: 100%;">
            </select>
        </td>
        <td class=" text-right" width="150px">0.000000%</td>
        <td class=" text-right" width="100px">0.00</td>
        <td class="text-left" width="150px"></td>
    </tr>
</table>

		</div>
	</body>
	<script src="/12366/www.12366.ha.cn/Application/Home/Common/js/table.js"></script>
</html>