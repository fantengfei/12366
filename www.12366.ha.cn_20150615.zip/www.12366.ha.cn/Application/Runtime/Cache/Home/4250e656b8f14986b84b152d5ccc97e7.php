<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>
	<head>
		<title>html</title>
		<meta http-equiv="content-type" content="text/html charset=utf8">
		<script src="/12366/www.12366.ha.cn/Application/Home/Common/js/jquery-1.4.3.min.js"></script>
        <script src="/12366/www.12366.ha.cn/Public/ext/ext-all.js"></script>
<!--<script src="/12366/www.12366.ha.cn/Public/ext/bootstrap.js"></script>-->
<script src="/12366/www.12366.ha.cn/Public/ext/packages/ext-locale/build/ext-locale-zh_CN.js"></script>
<link href="/12366/www.12366.ha.cn/Public/ext/packages/ext-theme-classic/build/resources/ext-theme-classic-all.css" rel="stylesheet" />
<!--<link href="/12366/www.12366.ha.cn/Public/ext/packages/ext-theme-neptune/build/resources/ext-theme-neptune-all.css" rel="stylesheet" />-->
<!--<link href="/12366/www.12366.ha.cn/Public/ext/packages/ext-theme-gray/build/resources/ext-theme-gray-all.css" rel="stylesheet" />-->
        <script type="text/javascript">  
		   Ext.onReady(function(){  
				var md = new Ext.form.DateField({  
					name:"startDate",  
					editable:false, //不允许对日期进行编辑  
					width:100,  
					format:"Y-m-d",  
					emptyText:"请选择日期..."  
				});  
				md.render('time');  
		   });
		   
		   
		    Ext.onReady(function(){  
				var md = new Ext.form.DateField({  
					name:"endDate",  
					editable:false, //不允许对日期进行编辑  
					width:100,  
					format:"Y-m-d",  
					emptyText:"请选择日期..."  
				});  
				md.render('time1');  
		   });  
       </script>

		<style>
            .icon .divimage{
                background-image:url('/12366/www.12366.ha.cn/Application/Home/Common/image/trigon.png') ;
            }
          table tr td{ border:1px solid #e0e0e0; border-left:none;}
		</style>
	</head>
	<body id="body-base" style="background-color: #fff;">
        <div id="tool-bar">
        <form action="/12366/www.12366.ha.cn/index.php/Home/TableNode8/table4" method="post">
         <table border="0" cellpadding="0" cellspacing="0" height="32">
          <tr>
            <td width="210" align="center"  style="font-weight:400; font-size:12px;">
               <INPUT class="scene" name="shenbao" type="radio"  value="1">扣款日期
               <input type="radio" name="shenbao"  value="2" >所属日期
            </td>
            <td  width="80" align="center" bgcolor="#f9f9f9">
             开始日期：
            </td>
            <td id="time"  width="106" align="center">
            
            </td>
            
             <td  width="80" align="center" bgcolor="#f9f9f9">
             结束日期：
            </td>
            <td id="time1"  width="106" align="center">
            
            </td>
             <td >
             <input type="submit" value="" style="background:url(/12366/www.12366.ha.cn/Application/Home/Common/icon/search.png) no-repeat; width:76px; height:23px;  border:none;">
            </td>
           </tr>
          </table>
         </form>
        </div>
		<div id= 'bodydiv' style="overflow:auto;">
            
<hr style=" border:1px dashed   #b9d0d6"></hr>
<div style="height:300px;border:1px solid #d9d9d9;width:1400px;">
<table cellpadding="0" cellspacing="0" id="bodytable"  style="border-top:2px solid #900;  overflow:scroll; height:28px;" >
 <tr style=" background:#f0f0f0; font-weight:600; font-size:12px;"> 
   <td colspan="7" align="center" width="160" style="border:1px solid #d0d0d0;border-left:none "> 扣款日期</td>
   <td colspan="7" align="center" width="160" style="border:1px solid #d0d0d0;border-left:none ">所属日期</td>
   <td colspan="7" align="center" width="160" style="border:1px solid #d0d0d0;border-left:none ">税种</td>
   <td colspan="7" align="center" width="160" style="border:1px solid #d0d0d0;border-left:none ">项目名称</td>
    <td colspan="7" align="center" width="160" style="border:1px solid #d0d0d0;border-left:none ">扣款金额</td>
     <td colspan="7" align="center" width="160" style="border:1px solid #d0d0d0;border-left:none ">税票号码</td>
     <td colspan="7" align="center" width="160" style="border:1px solid #d0d0d0;border-left:none ">凭证序号</td>
      <td colspan="7" align="center" width="160" style="border:1px solid #d0d0d0;border-left:none ">扣款日期</td>
      <td colspan="7" align="center" width="160" style="border:1px solid #d0d0d0;border-left:none ">扣款信息</td
    
   
 ></tr>
 <?php if(is_array($res)): foreach($res as $key=>$v): if($v['num']%2 != 0 ): ?><tr  style=" border:#d9d9d9 1px;" height="28" id="tabledata">
   
   
   <td colspan="7" align="left" style="border:1px solid #d0d0d0;border-left:none "><?php echo ($v["update_time"]); ?></td>
   <td colspan="7" align="left" style="border:1px solid #d0d0d0;border-left:none "><?php echo ($v["create_time"]); ?></td>
  <td colspan="7" align="center" width="160" style="border:1px solid #d0d0d0;border-left:none ">税种</td>
   <td colspan="7" align="center" width="160" style="border:1px solid #d0d0d0;border-left:none "><?php echo ($v["table_name"]); ?></td>
    <td colspan="7" align="center" width="160" style="border:1px solid #d0d0d0;border-left:none ">扣款金额</td>
     <td colspan="7" align="center" width="160" style="border:1px solid #d0d0d0;border-left:none ">税票号码</td>
     <td colspan="7" align="center" width="160" style="border:1px solid #d0d0d0;border-left:none ">凭证序号</td>
      <td colspan="7" align="center" width="160" style="border:1px solid #d0d0d0;border-left:none ">扣款日期</td>
      <td colspan="7" align="center" width="160" style="border:1px solid #d0d0d0;border-left:none ">扣款信息</td
 ></tr>
 <?php else: ?>
 <tr  style=" background:#f0f0f0;" height="28">

   <td colspan="7" align="left" style="border:1px solid #d0d0d0;border-left:none "><?php echo ($v["update_time"]); ?></td>
   <td colspan="7" align="left" style="border:1px solid #d0d0d0;border-left:none "><?php echo ($v["create_time"]); ?></td>
   <td colspan="7" align="center" width="160" style="border:1px solid #d0d0d0;border-left:none ">税种</td>
    <td colspan="7" align="center" width="160" style="border:1px solid #d0d0d0;border-left:none "><?php echo ($v["table_name"]); ?></td>
 
    <td colspan="7" align="center" width="160" style="border:1px solid #d0d0d0;border-left:none ">扣款金额</td>
     <td colspan="7" align="center" width="160" style="border:1px solid #d0d0d0;border-left:none ">税票号码</td>
     <td colspan="7" align="center" width="160" style="border:1px solid #d0d0d0;border-left:none ">凭证序号</td>
      <td colspan="7" align="center" width="160" style="border:1px solid #d0d0d0;border-left:none ">扣款日期</td>
      <td colspan="7" align="center" width="160" style="border:1px solid #d0d0d0;border-left:none ">扣款信息</td
 ></tr><?php endif; endforeach; endif; ?> 
</table></div>
<div  style="margin:0 auto; width:200px;">
  <p>共<span style=" color:red;"><?php echo ($count); ?></span>条记录</p>
</div>

		</div>
	</body>
	<script src="/12366/www.12366.ha.cn/Application/Home/Common/js/table.js"></script>
</html>