<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>
	<head>
		<title>html</title>
		<meta http-equiv="content-type" content="text/html charset=utf8">
		<link rel="stylesheet" type="text/css" href="/12366/www.12366.ha.cn/Application/Home/Common/css/table.css" media="all">
		<script src="/12366/www.12366.ha.cn/Application/Home/Common/js/jquery-1.4.3.min.js"></script>

        <script src="/12366/www.12366.ha.cn/Public/ext/ext-all.js"></script>
<!--<script src="/12366/www.12366.ha.cn/Public/ext/bootstrap.js"></script>-->
<script src="/12366/www.12366.ha.cn/Public/ext/packages/ext-locale/build/ext-locale-zh_CN.js"></script>
<link href="/12366/www.12366.ha.cn/Public/ext/packages/ext-theme-classic/build/resources/ext-theme-classic-all.css" rel="stylesheet" />
<!--<link href="/12366/www.12366.ha.cn/Public/ext/packages/ext-theme-neptune/build/resources/ext-theme-neptune-all.css" rel="stylesheet" />-->
<!--<link href="/12366/www.12366.ha.cn/Public/ext/packages/ext-theme-gray/build/resources/ext-theme-gray-all.css" rel="stylesheet" />-->
<script type="text/javascript">

    /**
     * 选项池，
     *
     * 标准字段有：‘保存，删除，打印预览，提取数据，修改本年累计’
     *
     * 应用范例：
     *
     * <\include file="./Application/Home/Common/html/toolbar.html" />
     * <\script type="text/javascript">
     *       Ext.onReady(function(){
     *           var option = ['保存','-' ,'删除'];
     *          createOptions(option);
     *       });
     * <\/script>
     *
     * */

    var option = [{
        xtype: 'button', // default for Toolbars
        text: '保存',
        icon: '/12366/www.12366.ha.cn/Application/Home/Common/icon/save-icon.png',
        listeners: {
            click: {
                fn: function() {

                    var table_data = Ext.get('bodydiv').getHtml();
                    var root_name  = $('#root_name').val();
                    var table_name = $('#table_name').val();
                    var table_type = $('#table_type').val();
                    var table_url  = $('#table_url').val();


//                    var win = Ext.create("Ext.window.Window", {
//                        id: "myWin",
//                        title: "保存",
//                        width: 400,
//                        height: 200,
//                        layout: "fit",
//                        items: [
//                            {
//                                xtype: 'datefield',
//                                id: 'save_time',
//                                width: 100,
//                                fieldLabel: '保存时间',
//                                name: 'to_date',
//                                format: 'Y-m-d',
//                                editable: false,
//                                allowBlank: false,
//                                value: new Date()
//                            }
//                        ],
//                        buttons: [
//                            { xtype: "button", text: "确定", handler: function () {
//
//                                var currentTime = Ext.util.Format.date(new Date(Ext.getCmp('save_time').getValue()), 'Y-m-d');
//
//                                Ext.Ajax.request({
//                                    url: '/12366/www.12366.ha.cn/index.php/Home/Index/save_table',
//                                    params: {
//                                        table_data:table_data,
//                                        root_name :root_name,
//                                        table_name:table_name,
//                                        table_type:table_type,
//                                        table_url :table_url,
//                                        save_time: currentTime
//                                    },
//                                    success: function(response){
//                                        var text = response.responseText;
//                                        if(text == 'success'){
//                                            alert("成功！");
//                                        }else{
//                                            alert("失败！");
//                                        }
//
//                                        win.close();
//                                    }
//                                });
//
//
//                            } },
//                            { xtype: "button", text: "取消", handler: function () { this.up("window").close(); } }
//                        ]
//                    });
//
//                    win.show();
                    var win = Ext.create("Ext.window.Window", {
                        id: "myWin",
                        title: "保存",
                        width: 500,
                        height: 100,
                        layout: "fit",
                        items: [
                            {
                                xtype: "form",
                                defaultType: 'textfield',
                                defaults: {
                                    anchor: '100%'
                                },
                                fieldDefaults: {
                                    labelWidth: 80,
                                    labelAlign: "left",
                                    flex: 1,
                                    margin: 5
                                },
                                items: [
                                    {
                                        xtype: "container",
                                        layout: "hbox",
                                        items: [
                                            {
                                                xtype: 'datefield',
                                                id: 'save_time',
                                                width: 100,
                                                fieldLabel: '保存时间',
                                                name: 'to_date',
                                                format: 'Y-m-d',
                                                editable: false,
                                                allowBlank: false,
                                                value: new Date()
                                            }
                                        ]
                                    }
                                ]
                            }
                        ],
                        buttons: [
                            { xtype: "button", text: "确定", handler: function () {

                                var isShow = 1;

                                if (!confirm("是否在查询打印里显示？")) {
                                    isShow = 0;
                                }
                                var currentTime = Ext.util.Format.date(new Date(Ext.getCmp('save_time').getValue()), 'Y-m-d');
                                Ext.Ajax.request({
                                    url: '/12366/www.12366.ha.cn/index.php/Home/Index/save_table',
                                    params: {
                                        table_data:table_data,
                                        root_name :root_name,
                                        table_name:table_name,
                                        table_type:table_type,
                                        table_url :table_url,
                                        save_time: currentTime,
                                        is_show: isShow
                                    },
                                    success: function(response){
                                        var text = response.responseText;
                                        if(text == 'success'){
                                            alert("成功！");
                                        }else{
                                            alert("失败！");
                                        }

                                        win.close();
                                    }
                                });
                            } },
                            { xtype: "button", text: "取消", handler: function () { this.up("window").close(); } }
                        ]
                    });

                    win.show();

                }
            }
        }
    },'-', {
        xtype: 'button',
        text : '删除',
        icon: '/12366/www.12366.ha.cn/Application/Home/Common/icon/return.png'
    },'-', {
        xtype:'button',
        text: '打印预览',
        icon: '/12366/www.12366.ha.cn/Application/Home/Common/icon/yulandayin.png'
    },'-', {
        xtype: 'button',
        text: '提取数据',
        icon:'/12366/www.12366.ha.cn/Application/Home/Common/icon/xuanzhuan.png'
    },'-',{
        xtype: 'checkbox',
        boxLabel: '修改本年累计'
    },'->', {
        xtype: 'button',
        icon: '/12366/www.12366.ha.cn/Application/Home/Common/icon/help.jpg'
    }];

    function save() {

    }

    function createOptions(item) {

        var items = [];

        if (item == null) {
            items = option;
        } else {
            for (var j=0; j< item.length; j++) {
                if (item[j] == '-') {
                    items.push('-');
                    continue;
                }
                for (var i=0; i< option.length; i++) {
                    if (item[j] == option[i].text) {
                        items.push(option[i]);
                        break;
                    }
                }
            }
        }

        Ext.create('Ext.toolbar.Toolbar', {
            renderTo: 'tool-bar',
            border: false,
            items: items
        });
    }

    Ext.onReady(function(){

        // 设置 ‘bodydiv’ 元素的 style
        Ext.get('bodydiv').setHeight(document.documentElement.clientHeight - 28);
        Ext.fly('bodydiv').setStyle({
            border: 'solid 1px #000000',
            overflow:'auto'
        });
    });
</script>

        <script type="text/javascript">
            Ext.onReady(function(){
                createOptions();
            });
        </script>

		<style>
            .icon .divimage{
                background-image:url('/12366/www.12366.ha.cn/Application/Home/Common/image/trigon.png') ;
            }

		</style>
	</head>
	<body id="body-base" style="background-color: #ede6d7;">
        <div id="tool-bar"></div>
		<div id= 'bodydiv'>
            
<input type='hidden' id="table_url" value="<?php echo ($table_url); ?>">
<input type='hidden' id="root_name" value="居民企业所得税2014（年报A）">
<input type='hidden' id="table_name" value="中华人名共和国企业所得税年度纳税申报表（A类）">
<input type='hidden' id="table_type" value="2">
<table id="bodytable" width="670px;">
<tr class='titletr title-notic'>
    <td colspan = '5' id='titletd'>中华人名共和国企业所得税年度纳税申报表（A类）</td>
</tr>
<tr class='titletr'>
    <td colspan = '5'>&nbsp;</td>
</tr>
<tr class='titletr'>
    <td colspan = '5'>&nbsp;</td>
</tr>
<tr class='titletr'>
    <td colspan = '5'>税款所属期：2015年02月01日至2015年02月28日</td>
</tr>
<tr class='titletr'>
    <td colspan = '5'>纳税人名称：（公章）河南起重机械有限公司</td>
</tr>
<tr class='titletr'>
    <td colspan = '4'>纳税人识别号：410711775106396</td>
    <td class = 'text-right'>金额单位：元（至角至分）</td>
</tr>
<tr>
    <td class='gauge-style text-center'>类别</td>
    <td class='gauge-style text-center'>行次</td>
    <td class='gauge-style text-center' colspan="2">项目</td>
    <td class='gauge-style text-center'>金额</td>
</tr>
<tr>
    <td class='gauge-style text-center' rowspan="13">极润总额计算</td>
    <td class='gauge-style text-center'>1</td>
    <td class='gauge-style text-left' colspan="2">一、营业收入（填A101010\101020\103000）</td>
    <td class ='tddata icon'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
</tr>
<tr>
    <td class='gauge-style text-center'>2</td>
    <td class='gauge-style text-left' colspan="2">&emsp;&emsp;减：营业成本（填写A102010\102020\103000）</td>
    <td class ='tddata icon'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
</tr>
<tr>
    <td class='gauge-style text-center'>3</td>
    <td class='gauge-style text-left' colspan="2">&emsp;&emsp;营业税金及附加</td>
    <td class ='tddata icon'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
</tr>
<tr>
    <td class='gauge-style text-center'>4</td>
    <td class='gauge-style text-left' colspan="2">&emsp;&emsp;销售费用（填写A104000）</td>
    <td class ='tddata icon'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
</tr>
<tr>
    <td class='gauge-style text-center'>5</td>
    <td class='gauge-style text-left' colspan="2">&emsp;&emsp;管理费用（填写A104000）</td>
    <td class ='tddata icon'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
</tr>
<tr>
    <td class='gauge-style text-center'>6</td>
    <td class='gauge-style text-left' colspan="2">&emsp;&emsp;财务费用（填写A104000）</td>
    <td class ='tddata icon'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
</tr>
<tr>
    <td class='gauge-style text-center'>7</td>
    <td class='gauge-style text-left' colspan="2">&emsp;&emsp;资产减值损失</td>
    <td class ='tddata'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
</tr>
<tr>
    <td class='gauge-style text-center'>8</td>
    <td class='gauge-style text-left' colspan="2">&emsp;&emsp;加：公允价值变动收益</td>
    <td class ='tddata'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
</tr>
<tr>
    <td class='gauge-style text-center'>9</td>
    <td class='gauge-style text-left' colspan="2">&emsp;&emsp;投资收益</td>
    <td class ='tddata'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
</tr>
<tr>
    <td class='gauge-style text-center'>10</td>
    <td class='gauge-style text-left' colspan="2">二、营业利润（1-2-3-4-5-6-7-8-9）</td>
    <td class ='tddata gray'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
</tr>
<tr>
    <td class='gauge-style text-center'>11</td>
    <td class='gauge-style text-left' colspan="2">&emsp;&emsp;加：营业外收入（填写A102010\102020\103000）</td>
    <td class ='tddata icon'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
</tr>
<tr>
    <td class='gauge-style text-center'>12</td>
    <td class='gauge-style text-left' colspan="2">&emsp;&emsp;减：营业外支出（填写A102010\102020\103000）</td>
    <td class ='tddata icon'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
</tr>
<tr>
    <td class='gauge-style text-center'>13</td>
    <td class='gauge-style text-left' colspan="2">三、利润总额（10+11-12）</td>
    <td class ='tddata gray'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
</tr>
<tr>
    <td class='gauge-style text-center' rowspan="10">&emsp;&emsp;应纳税所得额计算</td>
    <td class='gauge-style text-center'>14</td>
    <td class='gauge-style text-left' colspan="2">&emsp;&emsp;减：境外所得（填写A108000，A108010）</td>
    <td class ='tddata icon'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
</tr>
<tr>
    <td class='gauge-style text-center'>15</td>
    <td class='gauge-style text-left' colspan="2">&emsp;&emsp;加：纳税调整增加额（填写A105000）</td>
    <td class ='tddata icon'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
</tr><tr>
    <td class='gauge-style text-center'>16</td>
    <td class='gauge-style text-left' colspan="2">&emsp;&emsp;减：纳税调整减少额（填写A105000）</td>
    <td class ='tddata icon'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
</tr><tr>
    <td class='gauge-style text-center'>17</td>
    <td class='gauge-style text-left' colspan="2">&emsp;&emsp;减：免税，减计收入及加计扣除（填写A107010）</td>
    <td class ='tddata icon'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
</tr><tr>
    <td class='gauge-style text-center'>18</td>
    <td class='gauge-style text-left' colspan="2">&emsp;&emsp;加：境外应税所得递减境内亏损（填写A108000）</td>
    <td class ='tddata icon'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
</tr><tr>
    <td class='gauge-style text-center'>19</td>
    <td class='gauge-style text-left' colspan="2">四、纳税调整后所得（13-14+15-16-17-18）</td>
    <td class ='tddata gray'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
</tr><tr>
    <td class='gauge-style text-center'>20</td>
    <td class='gauge-style text-left' colspan="2">&emsp;&emsp;减：所得减免（填写A107020）</td>
    <td class ='tddata icon'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
</tr><tr>
    <td class='gauge-style text-center'>21</td>
    <td class='gauge-style text-left' colspan="2">&emsp;&emsp;减：抵扣应纳税所得额（填写A107030）</td>
    <td class ='tddata icon'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
</tr><tr>
    <td class='gauge-style text-center'>22</td>
    <td class='gauge-style text-left' colspan="2">&emsp;&emsp;减：弥补以前年度亏损（填写A106000）</td>
    <td class ='tddata icon'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
</tr><tr>
    <td class='gauge-style text-center'>23</td>
    <td class='gauge-style text-left' colspan="2">五、应纳税所得额（19-20-21-22）</td>
    <td class ='tddata gray icon'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
</tr><tr>
     <td class='gauge-style text-center' rowspan="13">&emsp;&emsp;应纳税所得额计算</td>
    <td class='gauge-style text-center'>24</td>
    <td class='gauge-style text-left' colspan="2">&emsp;&emsp;税率（25%）</td>
    <td class ='tddata gray'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
</tr><tr>
    <td class='gauge-style text-center'>25</td>
    <td class='gauge-style text-left' colspan="2">六、应纳税所得额（23x4）</td>
    <td class ='tddata gray'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
</tr><tr>
    <td class='gauge-style text-center'>26</td>
    <td class='gauge-style text-left' colspan="2">&emsp;&emsp;减：减免所得税额（填写A107040）</td>
    <td class ='tddata icon'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
</tr><tr>
    <td class='gauge-style text-center'>27</td>
    <td class='gauge-style text-left' colspan="2">&emsp;&emsp;减：减免所得税额（填写A107050）</td>
    <td class ='tddata icon'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
</tr><tr>
    <td class='gauge-style text-center'>28</td>
    <td class='gauge-style text-left' colspan="2">七、应纳税额（25-26-27）</td>
    <td class ='tddata gray'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
</tr><tr>
    <td class='gauge-style text-center'>29</td>
    <td class='gauge-style text-left' colspan="2">&emsp;&emsp;加：境外所得应纳所得税额（填写A108000）</td>
    <td class ='tddata icon'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
</tr><tr>
    <td class='gauge-style text-center'>30</td>
    <td class='gauge-style text-left' colspan="2">&emsp;&emsp;减：境外所得抵免所得税额（填写A108000）</td>
    <td class ='tddata icon'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
</tr><tr>
    <td class='gauge-style text-center'>31</td>
    <td class='gauge-style text-left' colspan="2">八、实际应纳所得税额（28+29-30）</td>
    <td class ='tddata gray'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
</tr><tr>
    <td class='gauge-style text-center'>32</td>
    <td class='gauge-style text-left' colspan="2">&emsp;&emsp;减：本年累计实际已预缴的所得税额</td>
    <td class ='tddata gray icon'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
</tr><tr>
    <td class='gauge-style text-center'>33</td>
    <td class='gauge-style text-left' colspan="2">九、本年应补（退）所得税额（31-32）</td>
    <td class ='tddata gray'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
</tr><tr>
    <td class='gauge-style text-center'>34</td>
    <td class='gauge-style text-left' colspan="2">&emsp;&emsp;其中：总机构分摊年（退）所得税额（填写A109000）</td>
    <td class ='tddata icon'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
</tr><tr>
    <td class='gauge-style text-center'>35</td>
    <td class='gauge-style text-left' colspan="2">&emsp;&emsp;财政集中分配本年应补（退）所得税额（填写A109000）</td>
    <td class ='tddata icon'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
</tr><tr>
    <td class='gauge-style text-center'>36</td>
    <td class='gauge-style text-left' colspan="2">&emsp;&emsp;中机构主体生产经营部门分摊本年应补（退）所得税额（填写A109000）</td>
    <td class ='tddata icon'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
</tr>
<tr>
    <td class='gauge-style text-center' rowspan="2">&emsp;&emsp;附列资料</td>
    <td class='gauge-style text-center'>37</td>
    <td class='gauge-style text-left' colspan="2">&emsp;&emsp;以前年度多缴的所得税额在本年抵减额</td>
    <td class ='tddata icon'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
</tr><tr>
    <td class='gauge-style text-center'>38</td>
    <td class='gauge-style text-left' colspan="2">&emsp;&emsp;以前本年度应缴未缴在本年入库所得税额</td>
    <td class ='tddata icon'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
</tr>
<tr class="trfoot">
    <td colspan="3" style="border-top: 0px; border-bottom: 0px;">纳税人公章：</td>
    <td  style="border-top: 0px; border-bottom: 0px;">代理申报中介机构公章：</td>
    <td  style="border-top: 0px; border-bottom: 0px;">主管税务机关受理专用章：</td>
</tr>
<tr class="trfoot">
    <td colspan="3"  style="border-top: 0px; border-bottom: 0px;">经办人：</td>
    <td  style="border-top: 0px; border-bottom: 0px;">经办人及职业证件号码：</td>
    <td  style="border-top: 0px; border-bottom: 0px;">受理人：</td>
</tr>
<tr class="trfoot">
    <td colspan="3"  style="border-top: 0px; border-bottom: 0px;">申报日期：</td>
    <td  style="border-top: 0px; border-bottom: 0px;">代理申报日期： 年 月 日</td>
    <td  style="border-top: 0px; border-bottom: 0px;">受理日期：</td>
</tr>
<tr class="titletr" style="border-top: 1px solid #000;">
    <td width="37px;">&nbsp;</td>
    <td width="37px">&nbsp;</td>
    <td width="150px;">&nbsp;</td>
    <td width="300px;">&nbsp;</td>
    <td width="200px;">&nbsp;</td>
</tr>
</table>

		</div>
	</body>
	<script src="/12366/www.12366.ha.cn/Application/Home/Common/js/table.js"></script>
</html>