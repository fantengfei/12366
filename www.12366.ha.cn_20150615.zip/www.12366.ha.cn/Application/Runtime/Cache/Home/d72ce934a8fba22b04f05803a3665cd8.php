<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>
	<head>
		<title>html</title>
		<meta http-equiv="content-type" content="text/html charset=utf8">
		<link rel="stylesheet" type="text/css" href="/12366/www.12366.ha.cn/Application/Home/Common/css/table.css" media="all">
		<script src="/12366/www.12366.ha.cn/Application/Home/Common/js/jquery-1.4.3.min.js"></script>

        <script src="/12366/www.12366.ha.cn/Public/ext/ext-all.js"></script>
<!--<script src="/12366/www.12366.ha.cn/Public/ext/bootstrap.js"></script>-->
<script src="/12366/www.12366.ha.cn/Public/ext/packages/ext-locale/build/ext-locale-zh_CN.js"></script>
<link href="/12366/www.12366.ha.cn/Public/ext/packages/ext-theme-classic/build/resources/ext-theme-classic-all.css" rel="stylesheet" />
<!--<link href="/12366/www.12366.ha.cn/Public/ext/packages/ext-theme-neptune/build/resources/ext-theme-neptune-all.css" rel="stylesheet" />-->
<!--<link href="/12366/www.12366.ha.cn/Public/ext/packages/ext-theme-gray/build/resources/ext-theme-gray-all.css" rel="stylesheet" />-->
<script type="text/javascript">

    /**
     * 选项池，
     *
     * 标准字段有：‘保存，删除，打印预览，提取数据，修改本年累计’
     *
     * 应用范例：
     *
     * <\include file="./Application/Home/Common/html/toolbar.html" />
     * <\script type="text/javascript">
     *       Ext.onReady(function(){
     *           var option = ['保存','-' ,'删除'];
     *          createOptions(option);
     *       });
     * <\/script>
     *
     * */

    var option = [{
        xtype: 'button', // default for Toolbars
        text: '保存',
        icon: '/12366/www.12366.ha.cn/Application/Home/Common/icon/save-icon.png',
        listeners: {
            click: {
                fn: function() {

                    var table_data = Ext.get('bodydiv').getHtml();
                    var root_name  = $('#root_name').val();
                    var table_name = $('#table_name').val();
                    var table_type = $('#table_type').val();
                    var table_url  = $('#table_url').val();


//                    var win = Ext.create("Ext.window.Window", {
//                        id: "myWin",
//                        title: "保存",
//                        width: 400,
//                        height: 200,
//                        layout: "fit",
//                        items: [
//                            {
//                                xtype: 'datefield',
//                                id: 'save_time',
//                                width: 100,
//                                fieldLabel: '保存时间',
//                                name: 'to_date',
//                                format: 'Y-m-d',
//                                editable: false,
//                                allowBlank: false,
//                                value: new Date()
//                            }
//                        ],
//                        buttons: [
//                            { xtype: "button", text: "确定", handler: function () {
//
//                                var currentTime = Ext.util.Format.date(new Date(Ext.getCmp('save_time').getValue()), 'Y-m-d');
//
//                                Ext.Ajax.request({
//                                    url: '/12366/www.12366.ha.cn/index.php/Home/Index/save_table',
//                                    params: {
//                                        table_data:table_data,
//                                        root_name :root_name,
//                                        table_name:table_name,
//                                        table_type:table_type,
//                                        table_url :table_url,
//                                        save_time: currentTime
//                                    },
//                                    success: function(response){
//                                        var text = response.responseText;
//                                        if(text == 'success'){
//                                            alert("成功！");
//                                        }else{
//                                            alert("失败！");
//                                        }
//
//                                        win.close();
//                                    }
//                                });
//
//
//                            } },
//                            { xtype: "button", text: "取消", handler: function () { this.up("window").close(); } }
//                        ]
//                    });
//
//                    win.show();
                    var win = Ext.create("Ext.window.Window", {
                        id: "myWin",
                        title: "保存",
                        width: 500,
                        height: 100,
                        layout: "fit",
                        items: [
                            {
                                xtype: "form",
                                defaultType: 'textfield',
                                defaults: {
                                    anchor: '100%'
                                },
                                fieldDefaults: {
                                    labelWidth: 80,
                                    labelAlign: "left",
                                    flex: 1,
                                    margin: 5
                                },
                                items: [
                                    {
                                        xtype: "container",
                                        layout: "hbox",
                                        items: [
                                            {
                                                xtype: 'datefield',
                                                id: 'save_time',
                                                width: 100,
                                                fieldLabel: '保存时间',
                                                name: 'to_date',
                                                format: 'Y-m-d',
                                                editable: false,
                                                allowBlank: false,
                                                value: new Date()
                                            }
                                        ]
                                    }
                                ]
                            }
                        ],
                        buttons: [
                            { xtype: "button", text: "确定", handler: function () {

                                var isShow = 1;

                                if (!confirm("是否在查询打印里显示？")) {
                                    isShow = 0;
                                }
                                var currentTime = Ext.util.Format.date(new Date(Ext.getCmp('save_time').getValue()), 'Y-m-d');
                                Ext.Ajax.request({
                                    url: '/12366/www.12366.ha.cn/index.php/Home/Index/save_table',
                                    params: {
                                        table_data:table_data,
                                        root_name :root_name,
                                        table_name:table_name,
                                        table_type:table_type,
                                        table_url :table_url,
                                        save_time: currentTime,
                                        is_show: isShow
                                    },
                                    success: function(response){
                                        var text = response.responseText;
                                        if(text == 'success'){
                                            alert("成功！");
                                        }else{
                                            alert("失败！");
                                        }

                                        win.close();
                                    }
                                });
                            } },
                            { xtype: "button", text: "取消", handler: function () { this.up("window").close(); } }
                        ]
                    });

                    win.show();

                }
            }
        }
    },'-', {
        xtype: 'button',
        text : '删除',
        icon: '/12366/www.12366.ha.cn/Application/Home/Common/icon/return.png'
    },'-', {
        xtype:'button',
        text: '打印预览',
        icon: '/12366/www.12366.ha.cn/Application/Home/Common/icon/yulandayin.png'
    },'-', {
        xtype: 'button',
        text: '提取数据',
        icon:'/12366/www.12366.ha.cn/Application/Home/Common/icon/xuanzhuan.png'
    },'-',{
        xtype: 'checkbox',
        boxLabel: '修改本年累计'
    },'->', {
        xtype: 'button',
        icon: '/12366/www.12366.ha.cn/Application/Home/Common/icon/help.jpg'
    }];

    function save() {

    }

    function createOptions(item) {

        var items = [];

        if (item == null) {
            items = option;
        } else {
            for (var j=0; j< item.length; j++) {
                if (item[j] == '-') {
                    items.push('-');
                    continue;
                }
                for (var i=0; i< option.length; i++) {
                    if (item[j] == option[i].text) {
                        items.push(option[i]);
                        break;
                    }
                }
            }
        }

        Ext.create('Ext.toolbar.Toolbar', {
            renderTo: 'tool-bar',
            border: false,
            items: items
        });
    }

    Ext.onReady(function(){

        // 设置 ‘bodydiv’ 元素的 style
        Ext.get('bodydiv').setHeight(document.documentElement.clientHeight - 28);
        Ext.fly('bodydiv').setStyle({
            border: 'solid 1px #000000',
            overflow:'auto'
        });
    });
</script>

        <script type="text/javascript">
            Ext.onReady(function(){
                createOptions();
            });
        </script>

		<style>
            .icon .divimage{
                background-image:url('/12366/www.12366.ha.cn/Application/Home/Common/image/trigon.png') ;
            }

		</style>
	</head>
	<body id="body-base" style="background-color: #ede6d7;">
        <div id="tool-bar"></div>
		<div id= 'bodydiv'>
            
<input type='hidden' id="table_url" value="<?php echo ($table_url); ?>">
<input type='hidden' id="root_name" value="居民企业所得税2014（年报A）">
<input type='hidden' id="table_name" value="一般企业收入明细表">
<input type='hidden' id="table_type" value="2">
<table id="bodytable" width="592px;">
<tr class='titletr title-notic'>
    <td colspan = '3' id='titletd'>一般企业收入明细表</td>
</tr>
<tr class='titletr title-notic'>
    <td colspan = '3' class='font-weight'>（税额抵减情况表）</td>
</tr>
<tr class='titletr'>
    <td colspan = '3'>&nbsp;</td>
</tr>
<tr class='titletr'>
    <td colspan = '3'>税款所属期：2015年02月01日至2015年02月28日</td>
</tr>
<tr class='titletr'>
    <td colspan = '3'>纳税人名称：（公章）河南起重机械有限公司</td>
</tr>
<tr class='titletr'>
    <td colspan = '3'>纳税人识别号：410711775106396</td>
</tr>
<tr>
    <td class='gauge-style text-center' style="width:
    72px;height:25px;">行次</td>
    <td class='gauge-style text-center' style="width:
    360px;">项目</td>
    <td class='gauge-style text-center' style='width:157px'>金额</td>
</tr>
<tr>
    <td class='gauge-style text-center' style="height:25px;">1</td>
    <td class='gauge-style text-left' style="width:173px;">一、营业收入（2+9）</td>
    <td class ='tddata gray'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
</tr>
<tr>
    <td class='gauge-style text-center' style="height:25px;">2</td>
    <td class='gauge-style text-left' style="width:173px;">&emsp;（一）主营业务收入（3+5+6+7+8）</td>
    <td class ='tddata gray'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
</tr>
<tr>
    <td class='gauge-style text-center' style="height:25px;" >3</td>
    <td class='gauge-style text-left' style="width:173px;">&emsp;&emsp;&emsp;1：销售商品收入</td>
    <td class ='tddata'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
</tr>
<tr>
    <td class='gauge-style text-center' style="height:25px;" >4</td>
    <td class='gauge-style text-left' style="width:173px;">&emsp;&emsp;&emsp;其中：非货币性资产交换收入</td>
    <td class ='tddata'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
</tr>
<tr>
    <td class='gauge-style text-center' style="height:25px;" >5</td>
    <td class='gauge-style text-left' style="width:173px;">&emsp;&emsp;&emsp;2：提供劳务收入</td>
    <td class ='tddata'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
</tr>
<tr>
    <td class='gauge-style text-center' style="height:25px;" >6</td>
    <td class='gauge-style text-left' style="width:173px;">&emsp;&emsp;&emsp;3：建造合同收入</td>
    <td class ='tddata'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
</tr>
<tr>
    <td class='gauge-style text-center' style="height:25px;" >7</td>
    <td class='gauge-style text-left' style="width:173px;">&emsp;&emsp;&emsp;4：让渡资产使用权收入</td>
    <td class ='tddata'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
</tr>
<tr>
    <td class='gauge-style text-center' style="height:25px;" >8</td>
    <td class='gauge-style text-left' style="width:173px;">&emsp;&emsp;&emsp;5：其他</td>
    <td class ='tddata'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
</tr>
<tr>
    <td class='gauge-style text-center' style="height:25px;" >9</td>
    <td class='gauge-style text-left' style="width:173px;">&emsp;（二）其他业务收入（10+12+13+14+15）</td>
    <td class ='tddata gray'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
</tr>
<tr>
    <td class='gauge-style text-center' style="height:25px;" >10</td>
    <td class='gauge-style text-left' style="width:173px;">&emsp;&emsp;&emsp;1：材料销售成本</td>
    <td class ='tddata'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
</tr>
<tr>
    <td class='gauge-style text-center' style="height:25px;" >11</td>
    <td class='gauge-style text-left' style="width:173px;">&emsp;&emsp;&emsp;其中：非货币性资产销售成本</td>
    <td class ='tddata'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
</tr>
<tr>
    <td class='gauge-style text-center' style="height:25px;" >12</td>
    <td class='gauge-style text-left' style="width:173px;">&emsp;&emsp;&emsp;2：出租固定资产成本</td>
    <td class ='tddata'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
</tr>
<tr>
    <td class='gauge-style text-center' style="height:25px;" >13</td>
    <td class='gauge-style text-left' style="width:173px;">&emsp;&emsp;&emsp;3：出租无形资产成本</td>
    <td class ='tddata'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
</tr>
<tr>
    <td class='gauge-style text-center' style="height:25px;" >14</td>
    <td class='gauge-style text-left' style="width:173px;">&emsp;&emsp;&emsp;4：包装物出租成本</td>
    <td class ='tddata'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
</tr>
<tr>
    <td class='gauge-style text-center' style="height:25px;" >15</td>
    <td class='gauge-style text-left' style="width:173px;">&emsp;&emsp;&emsp;5：其他</td>
    <td class ='tddata'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
</tr>
<tr>
    <td class='gauge-style text-center' style="height:25px;" >16</td>
    <td class='gauge-style text-left' style="width:173px;">二、营业外支出（17+18+19+20+21+22+23+24+25+26）</td>
    <td class ='tddata gray'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
</tr>
<tr>
    <td class='gauge-style text-center' style="height:25px;" >17</td>
    <td class='gauge-style text-left' style="width:173px;">&emsp;（一）非流动资产处置损失</td>
    <td class ='tddata'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
</tr>
<tr>
    <td class='gauge-style text-center' style="height:25px;" >18</td>
    <td class='gauge-style text-left' style="width:173px;">&emsp;（二）非货币性资产交换损失</td>
    <td class ='tddata'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
</tr>
<tr>
    <td class='gauge-style text-center' style="height:25px;" >19</td>
    <td class='gauge-style text-left' style="width:173px;">&emsp;（三）债务重组损失</td>
    <td class ='tddata'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
</tr>
<tr>
    <td class='gauge-style text-center' style="height:25px;" >20</td>
    <td class='gauge-style text-left' style="width:173px;">&emsp;（四）非常损失</td>
    <td class ='tddata'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
</tr>
<tr>
    <td class='gauge-style text-center' style="height:25px;" >21</td>
    <td class='gauge-style text-left' style="width:173px;">&emsp;（五）捐赠支出</td>
    <td class ='tddata'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
</tr>
<tr>
    <td class='gauge-style text-center' style="height:25px;" >22</td>
    <td class='gauge-style text-left' style="width:173px;">&emsp;（六）赞助支出</td>
    <td class ='tddata'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
</tr>
<tr>
    <td class='gauge-style text-center' style="height:25px;" >23</td>
    <td class='gauge-style text-left' style="width:173px;">&emsp;（七）罚设损失</td>
    <td class ='tddata'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
</tr>
<tr>
    <td class='gauge-style text-center' style="height:25px;" >24</td>
    <td class='gauge-style text-left' style="width:173px;">&emsp;（八）坏账损失</td>
    <td class ='tddata'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
</tr>
<tr>
    <td class='gauge-style text-center' style="height:25px;" >25</td>
    <td class='gauge-style text-left' style="width:173px;">&emsp;（九）无法收回的债券股权投资损失</td>
    <td class ='tddata gray icon'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
</tr>
<tr>
    <td class='gauge-style text-center' style="height:25px;" >26</td>
    <td class='gauge-style text-left' style="width:173px;">&emsp;（十）其他</td>
    <td class ='tddata'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
</tr>


</table>

		</div>
	</body>
	<script src="/12366/www.12366.ha.cn/Application/Home/Common/js/table.js"></script>
</html>