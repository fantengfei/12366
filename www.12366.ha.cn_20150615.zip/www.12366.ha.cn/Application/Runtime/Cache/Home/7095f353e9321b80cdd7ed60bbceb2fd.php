<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>
	<head>
		<title>html</title>
		<meta http-equiv="content-type" content="text/html charset=utf8">
		<script src="/12366/www.12366.ha.cn/Application/Home/Common/js/jquery-1.4.3.min.js"></script>

        <script src="/12366/www.12366.ha.cn/Public/ext/ext-all.js"></script>
<!--<script src="/12366/www.12366.ha.cn/Public/ext/bootstrap.js"></script>-->
<script src="/12366/www.12366.ha.cn/Public/ext/packages/ext-locale/build/ext-locale-zh_CN.js"></script>
<link href="/12366/www.12366.ha.cn/Public/ext/packages/ext-theme-classic/build/resources/ext-theme-classic-all.css" rel="stylesheet" />
<!--<link href="/12366/www.12366.ha.cn/Public/ext/packages/ext-theme-neptune/build/resources/ext-theme-neptune-all.css" rel="stylesheet" />-->
<!--<link href="/12366/www.12366.ha.cn/Public/ext/packages/ext-theme-gray/build/resources/ext-theme-gray-all.css" rel="stylesheet" />-->
<script type="text/javascript">

    /**
     * 选项池，
     *
     * 标准字段有：‘保存，删除，打印预览，提取数据，修改本年累计’
     *
     * 应用范例：
     *
     * <\include file="./Application/Home/Common/html/toolbar.html" />
     * <\script type="text/javascript">
     *       Ext.onReady(function(){
     *           var option = ['保存','-' ,'删除'];
     *          createOptions(option);
     *       });
     * <\/script>
     *
     * */

    var option = [{
        xtype: 'button', // default for Toolbars
        text: '申报数据',
        icon: '/12366/www.12366.ha.cn/Application/Home/Common/icon/savedata.png',
        listeners: {
            click: {
                fn: function() {
                    var shenbao = '已申报';
					var id={};
					var i=0;
					$(" input[type=checkbox]").each(function(){
                        if(this.checked){
                        id[i]=$(this).val();
						i++;
                       }
                     }); 
					   var trs = "";
					    $.each(id,function(n,value) {
						 trs += value+',';      
					   });
                  
                    Ext.Ajax.request({
                        url: '/12366/www.12366.ha.cn/index.php/Home/Index/edit_data',
                        params: {
                            shenbao:shenbao,
                            id:trs
                        },
                        success: function(response){
                            var text = response.responseText;
							window.location.href='/12366/www.12366.ha.cn/index.php/Home/TableNode8/table1' ;
                            if(text == 'success'){
                                alert("申报数据成功！");
                            }else{
                                alert("申报数据失败！");
                            }
                        }
                    });
                }
            }
        }
    },'-', {
        xtype: 'button',
        text : '修改数据',
        icon: '/12366/www.12366.ha.cn/Application/Home/Common/icon/editdata.png'
    },'-', {
        xtype:'button',
        text: '不同税表间审核',
        icon: '/12366/www.12366.ha.cn/Application/Home/Common/icon/checkdata.png'
    }];

    function createOptions(item) {

        var items = [];

        if (item == null) {
            items = option;
        } else {
            for (var j=0; j< item.length; j++) {
                if (item[j] == '-') {
                    items.push('-');
                    continue;
                }
                for (var i=0; i< option.length; i++) {
                    if (item[j] == option[i].text) {
                        items.push(option[i]);
                        break;
                    }
                }
            }
        }

        Ext.create('Ext.toolbar.Toolbar', {
            renderTo: 'tool-bar',
            border: false,
            items: items
        });
    }

    Ext.onReady(function(){

        // 设置 ‘bodydiv’ 元素的 style
        Ext.get('bodydiv').setHeight(document.documentElement.clientHeight - 28);
        Ext.fly('bodydiv').setStyle({
            border: 'solid 1px #b6cfd4',
            overflow:'auto'
        });
    });
</script>

        <script type="text/javascript">
            Ext.onReady(function(){
                createOptions();
            });
        </script>

		<style>
            .icon .divimage{
                background-image:url('/12366/www.12366.ha.cn/Application/Home/Common/image/trigon.png') ;
            }

		</style>
	</head>
	<body id="body-base" style="background-color: #fff;">
        <div id="tool-bar"></div>
		<div id= 'bodydiv'>
            
<hr style=" border:1px dashed   #b9d0d6"></hr>
<div style="height:300px;border:1px solid #d9d9d9">
<table width='100%' cellpadding="0" cellspacing="0" id="bodytable"  style="border-top:2px solid #900;"  >
 <tr style=" background:#f0f0f0; font-weight:600; font-size:12px;   height="28" >
   <td width="34" height="32" colspan="1" width="34" style="border:1px solid #d0d0d0; border-left:none "><input type="checkbox"  disabled="disabled"></td>
   <td colspan="8" align="left" height="28" width="202" style="border:1px solid #d0d0d0;border-left:none " >申报项目</td>
   <td colspan="7" align="left" width="160" style="border:1px solid #d0d0d0;border-left:none ">所属期起</td>
   <td colspan="7" align="left" width="160" style="border:1px solid #d0d0d0;border-left:none ">所属期止</td>
   <td colspan="7" align="left" width="160" style="border:1px solid #d0d0d0;border-left:none ">是否超过纳税期限</td>
   <td colspan="10" align="left" width="252" style="border:1px solid #d0d0d0;border-left:none ">申报结果代码</td>
   <td width="78" colspan="10" align="left" width="252">申报结果</td>
 </tr>
 <?php if(is_array($list)): foreach($list as $key=>$v): if($v['num']%2 != 0 ): ?><tr  style=" border:#d9d9d9 1px;" height="28" id="tabledata">
   <td height="41" colspan="1" width="34" style="border:1px solid #d0d0d0;border-left:none "><input type="checkbox" style="border:1px solid #000000;" value="<?php echo ($v["id"]); ?>"> </td>
   <td colspan="8" align="left" style="border:1px solid #d0d0d0;border-left:none "><?php echo ($v["table_name"]); ?></td>
   <td colspan="7" align="left" style="border:1px solid #d0d0d0;border-left:none "><?php echo ($v["create_time"]); ?></td>
   <td colspan="7" align="left" style="border:1px solid #d0d0d0;border-left:none "><?php echo ($v["update_time"]); ?></td>
   <td colspan="7" align="center" style=" color:#007d00;border:1px solid #d0d0d0;border-left:none">未过</td>
   <td colspan="10" align="left"  style="border:1px solid #d0d0d0;border-left:none ">申报项目</td>
   <td colspan="10" align="left" width="78"  style="border:1px solid #d0d0d0;border-left:none ">申报项目</td>
 </tr>
 <?php else: ?>
 <tr  style=" background:#f0f0f0;" height="28">
   <td height="41" colspan="1" width="34" style="border:1px solid #d0d0d0;border-left:none "><input type="checkbox" style="border:1px solid #000000;" value="<?php echo ($v["id"]); ?>"></td>
   <td colspan="8" align="left" style="border:1px solid #d0d0d0;border-left:none "><?php echo ($v["table_name"]); ?></td>
   <td colspan="7" align="left" style="border:1px solid #d0d0d0;border-left:none "><?php echo ($v["create_time"]); ?></td>
   <td colspan="7" align="left" style="border:1px solid #d0d0d0;border-left:none "><?php echo ($v["update_time"]); ?></td>
   <td colspan="7" align="center" style=" color:#007d00;border:1px solid #d0d0d0;border-left:none">未过</td>
   <td colspan="10" align="left"  style="border:1px solid #d0d0d0;border-left:none ">申报项目</td>
   <td colspan="10" align="left" width="78"  style="border:1px solid #d0d0d0;border-left:none ">申报项目</td>
 </tr><?php endif; endforeach; endif; ?> 
</table></div>
<table>

 <tr>
   <td>提示信息</td>
 </tr>
</table>

		</div>
	</body>
	<script src="/12366/www.12366.ha.cn/Application/Home/Common/js/table.js"></script>
</html>