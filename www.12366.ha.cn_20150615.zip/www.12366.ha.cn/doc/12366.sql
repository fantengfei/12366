-- phpMyAdmin SQL Dump
-- version phpStudy 2014
-- http://www.phpmyadmin.net
--
-- 主机: localhost
-- 生成日期: 2015 年 05 月 18 日 13:55
-- 服务器版本: 5.5.40
-- PHP 版本: 5.3.29

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- 数据库: `12366`
--
CREATE DATABASE  `12366` ;
-- --------------------------------------------------------

--
-- 表的结构 `table_info`
--
-- 创建时间: 2015 年 05 月 18 日 05:50
--

USE `12366`;

CREATE TABLE IF NOT EXISTS `table_info` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '数据id',
  `root_name` varchar(100) NOT NULL DEFAULT '' COMMENT '根目录名称（若树的级别超过两级，就保存最小级别的父级节点名称)',
  `table_name` varchar(100) NOT NULL DEFAULT '' COMMENT '表格名称（最小子节点名称）',
  `table_data` text NOT NULL COMMENT '表格数据（存放html代码）',
  `table_type` binary(1) NOT NULL DEFAULT '1' COMMENT '1:月季度，2:年季',
  `table_url` varchar(100) NOT NULL DEFAULT '' COMMENT '表格url',
  `is_show` tinyint(10) NOT NULL DEFAULT '1' COMMENT '1: 表示在查询打印中显示， 0：表示不显示',
  `create_time` int(11) NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) DEFAULT NULL COMMENT '更新时间（shenbao 字段的修改）',
  `shenbao` varchar(10) NOT NULL DEFAULT '已申报' COMMENT '已申报／未申报',
  `bianhao` varchar(10) DEFAULT NULL COMMENT '申报编号',
  `jieguo` varchar(10) DEFAULT NULL COMMENT '通过（申报结果）',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=18 ;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
