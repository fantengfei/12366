use `12366`;
ALTER TABLE table_info ADD ifkk tinyint(2) NOT NULL DEFAULT 0;
ALTER TABLE table_info ADD kk_time char(10) ;
ALTER TABLE  `table_info` CHANGE  `shenbao`  `shenbao` VARCHAR( 10 ) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT  '未申报' COMMENT '未申报／已申报';