Ext.define('Ext.aria.grid.column.Template', {
    override: 'Ext.grid.column.Template',
    
    requires: [
        'Ext.aria.grid.column.Column'
    ]
});
