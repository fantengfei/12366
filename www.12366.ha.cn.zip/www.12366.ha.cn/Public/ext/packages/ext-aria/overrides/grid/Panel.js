Ext.define('Ext.aria.grid.Panel', {
    override: 'Ext.grid.Panel',
    
    requires: [
        'Ext.aria.panel.Table',
        'Ext.aria.grid.View'
    ]
});
