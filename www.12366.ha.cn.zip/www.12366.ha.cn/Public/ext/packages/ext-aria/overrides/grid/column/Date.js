Ext.define('Ext.aria.grid.column.Date', {
    override: 'Ext.grid.column.Date',
    
    requires: [
        'Ext.aria.grid.column.Column'
    ]
});
