Ext.define('Ext.aria.grid.column.Action', {
    override: 'Ext.grid.column.Action',
    
    requires: [
        'Ext.aria.grid.column.Column'
    ]
});
