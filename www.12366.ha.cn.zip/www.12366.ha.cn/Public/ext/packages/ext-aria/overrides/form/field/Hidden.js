Ext.define('Ext.aria.form.field.Hidden', {
    override: 'Ext.form.field.Hidden',
    
    requires: [
        'Ext.aria.form.field.Base'
    ]
});
