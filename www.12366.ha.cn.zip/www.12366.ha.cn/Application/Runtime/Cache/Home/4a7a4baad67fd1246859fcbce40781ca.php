<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>
	<head>
		<title>html</title>
		<meta http-equiv="content-type" content="text/html charset=utf8">
		<link rel="stylesheet" type="text/css" href="/12366/www.12366.ha.cn/Application/Home/Common/css/table.css" media="all">
		<script src="/12366/www.12366.ha.cn/Application/Home/Common/js/jquery-1.4.3.min.js"></script>

        <script src="/12366/www.12366.ha.cn/Public/ext/ext-all.js"></script>
<!--<script src="/12366/www.12366.ha.cn/Public/ext/bootstrap.js"></script>-->
<script src="/12366/www.12366.ha.cn/Public/ext/packages/ext-locale/build/ext-locale-zh_CN.js"></script>
<link href="/12366/www.12366.ha.cn/Public/ext/packages/ext-theme-classic/build/resources/ext-theme-classic-all.css" rel="stylesheet" />
<!--<link href="/12366/www.12366.ha.cn/Public/ext/packages/ext-theme-neptune/build/resources/ext-theme-neptune-all.css" rel="stylesheet" />-->
<!--<link href="/12366/www.12366.ha.cn/Public/ext/packages/ext-theme-gray/build/resources/ext-theme-gray-all.css" rel="stylesheet" />-->
<script type="text/javascript">

    /**
     * 选项池，
     *
     * 标准字段有：‘保存，删除，打印预览，提取数据，修改本年累计’
     *
     * 应用范例：
     *
     * <\include file="./Application/Home/Common/html/toolbar.html" />
     * <\script type="text/javascript">
     *       Ext.onReady(function(){
     *           var option = ['保存','-' ,'删除'];
     *          createOptions(option);
     *       });
     * <\/script>
     *
     * */

    var option = [{
        xtype: 'button', // default for Toolbars
        text: '保存',
        icon: '/12366/www.12366.ha.cn/Application/Home/Common/icon/save-icon.png',
        listeners: {
            click: {
                fn: function() {
                    var table_data = Ext.get('bodydiv').getHtml();
                    var root_name  = $('#root_name').val();
                    var table_name = $('#table_name').val();
                    var table_type = $('#table_type').val();
                    var table_url  = $('#table_url').val();
                    Ext.Ajax.request({
                        url: '/12366/www.12366.ha.cn/index.php/Home/Index/save_table',
                        params: {
                            table_data:table_data,
                            root_name :root_name,
                            table_name:table_name,
                            table_type:table_type,
                            table_url :table_url
                        },
                        success: function(response){
                            var text = response.responseText;
                            if(text == 'success'){
                                alert("保存成功！");
                            }else{
                                alert("保存失败！");
                            }
                        }
                    });
                }
            }
        }
    },'-', {
        xtype: 'button',
        text : '删除',
        icon: '/12366/www.12366.ha.cn/Application/Home/Common/icon/return.png'
    },'-', {
        xtype:'button',
        text: '打印预览',
        icon: '/12366/www.12366.ha.cn/Application/Home/Common/icon/yulandayin.png'
    },'-', {
        xtype: 'button',
        text: '提取数据',
        icon:'/12366/www.12366.ha.cn/Application/Home/Common/icon/xuanzhuan.png'
    },'-',{
        xtype: 'checkbox',
        boxLabel: '修改本年累计'
    },'->', {
        xtype: 'button',
        icon: '/12366/www.12366.ha.cn/Application/Home/Common/icon/help.jpg'
    }];

    function createOptions(item) {

        var items = [];

        if (item == null) {
            items = option;
        } else {
            for (var j=0; j< item.length; j++) {
                if (item[j] == '-') {
                    items.push('-');
                    continue;
                }
                for (var i=0; i< option.length; i++) {
                    if (item[j] == option[i].text) {
                        items.push(option[i]);
                        break;
                    }
                }
            }
        }

        Ext.create('Ext.toolbar.Toolbar', {
            renderTo: 'tool-bar',
            border: false,
            items: items
        });
    }

    Ext.onReady(function(){

        // 设置 ‘bodydiv’ 元素的 style
        Ext.get('bodydiv').setHeight(document.documentElement.clientHeight - 28);
        Ext.fly('bodydiv').setStyle({
            border: 'solid 1px #000000',
            overflow:'auto'
        });
    });
</script>

        <script type="text/javascript">
            Ext.onReady(function(){
                createOptions();
            });
        </script>

		<style>
            .icon .divimage{
                background-image:url('/12366/www.12366.ha.cn/Application/Home/Common/image/trigon.png') ;
            }

		</style>
	</head>
	<body id="body-base">
        <div id="tool-bar"></div>
		<div id= 'bodydiv'>
            
<input type='hidden' id="table_url" value="<?php echo ($table_url); ?>">
<input type='hidden' id="root_name" value="增值税（一般纳税人使用）">
<input type='hidden' id="table_name" value="增值税纳税申请表附列资料（二）">
<input type='hidden' id="table_type" value="1">
<table id="bodytable" width="748px;">
<tr class='titletr title-notic'>
    <td colspan = '5' id='titletd'>增值税纳税申请表附列资料（二）</td>
</tr>
<tr class='titletr title-notic'>
    <td colspan = '5' class='font-weight'>（税额抵减情况表）</td>
</tr>
<tr class='titletr title-notic'>
    <td colspan = '5'>&nbsp;</td>
</tr>
<tr class='titletr'>
    <td colspan = '5'>&nbsp;</td>
</tr>
<tr class='titletr'>
    <td colspan = '5'>税款所属期：2015年02月01日至2015年02月28日</td>
</tr>
<tr class='titletr'>
    <td colspan = '3'>纳税人名称：（公章）河南起重机械有限公司</td>
    <td colspan = '2' class='text-right'>金额单位：元至角至分</td>
</tr>
<tr>
    <td class='gauge-style text-center font-weight' colspan="5">一.申报抵扣的进项税额</td>
</tr>
<tr>
    <td class='gauge-style text-center' style="width:297px;height:50px;">项目</td>
    <td class='gauge-style text-center' style='width:93px'>栏次</td>
    <td class='gauge-style text-center' style='width:114px'>份数</td>
    <td class='gauge-style text-center' style='width:114px'>金额</td>
    <td class='gauge-style text-center' style='width:114px'>税额</td>
</tr>
<tr>
    <td class='gauge-style text-left' style="width:105px;">（一）认证相符的税控增值税专用发票</td>
    <td class='gauge-style'>1=2+3</td>
    <td class ='tddata gray'>
        <div class='divimage'></div>
        <div class='divdata'>0</div>
    </td>
    <td class ='tddata gray'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
    <td class ='tddata gray'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
</tr>
<tr>
    <td class='gauge-style text-center' >其中：本期认证相符且本期申报抵扣</td>
    <td class='gauge-style text-left'>2</td>
    <td class ='tddata'>
        <div class='divimage'></div>
        <div class='divdata'>0</div>
    </td>
    <td class ='tddata'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
    <td class ='tddata'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
</tr>
<tr>
    <td class='gauge-style text-center' >前期认证相符且本期申报抵扣</td>
    <td class='gauge-style text-left'>3</td>
    <td class ='tddata'>
        <div class='divimage'></div>
        <div class='divdata'>0</div>
    </td>
    <td class ='tddata'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
    <td class ='tddata'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
</tr>
<tr>
    <td class='gauge-style text-left' >（二）其他扣税凭证</td>
    <td class='gauge-style text-left'>4=5+6+7+8</td>
    <td class ='tddata gray'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
    <td class ='tddata gray'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
    <td class ='tddata gray'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
</tr>
<tr>
    <td class='gauge-style text-center' >其中：海关进口增值税专用缴款书</td>
    <td class='gauge-style text-left'>5</td>
    <td class ='tddata gray icon'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
    <td class ='tddata'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
    <td class ='tddata gray icon'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
</tr>
<tr>
    <td class='gauge-style text-center' >农产品收购发票或者销售发票</td>
    <td class='gauge-style text-left'>6</td>
    <td class ='tddata'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
    <td class ='tddata'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
    <td class ='tddata'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
</tr>
<tr>
    <td class='gauge-style text-center' >代扣代缴税收缴款凭证</td>
    <td class='gauge-style text-left'>7</td>
    <td class ='tddata'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
    <td class ='tddata gray'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
    <td class ='tddata'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
</tr>
<tr>
    <td class='gauge-style text-center' >运输费用结算单据</td>
    <td class='gauge-style text-left'>8</td>
    <td class ='tddata'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
    <td class ='tddata'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
    <td class ='tddata'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
</tr>
<tr>
    <td class='gauge-style text-center'></td>
    <td class='gauge-style text-left'>9</td>
    <td class ='tddata gray'>
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
    </td>
    <td class ='tddata gray'>
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
    </td>
    <td class ='tddata gray'>
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
    </td>
</tr>
<tr>
    <td class='gauge-style text-center'></td>
    <td class='gauge-style text-left'>10</td>
    <td class ='tddata gray'>
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
    </td>
    <td class ='tddata gray'>
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
    </td>
    <td class ='tddata gray'>
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
    </td>
</tr>
<tr>
    <td class='gauge-style text-center' >（三）外贸企业进项税额抵扣说明</td>
    <td class='gauge-style text-left'>11</td>
    <td class ='tddata gray'>
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
    </td>
    <td class ='tddata gray'>
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
    </td>
    <td class ='tddata'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
</tr>
<tr>
    <td class='gauge-style text-center'>当期申报抵扣进项税额合计</td>
    <td class='gauge-style text-left'>12=1+4+11</td>
    <td class ='tddata gray'>
        <div class='divimage'></div>
        <div class='divdata'>0</div>
    </td>
    <td class ='tddata gray'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
    <td class ='tddata gray'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
</tr>
<tr>
    <td class='gauge-style text-center font-weight' colspan="5">二.进项税额转出额</td>
</tr>
<tr>
    <td class='gauge-style text-center' >项目</td>
    <td class='gauge-style text-center'>档次</td>
    <td class='gauge-style text-center' colspan="3">税额</td>
    
</tr>
<tr>
    <td class='gauge-style text-left' >本期进项税转出额</td>
    <td class='gauge-style text-left'>13=14至23之和</td>
    <td class ='tddata gray' colspan="3">
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>  
</tr>
<tr>
    <td class='gauge-style text-left' >其中：免税项目</td>
    <td class='gauge-style text-left'>14</td>
    <td class ='tddata' colspan="3">
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td> 
</tr>
<tr>
    <td class='gauge-style text-center' >非应税项目用.集体福利.个人消费</td>
    <td class='gauge-style text-left'>15</td>
    <td class ='tddata' colspan="3">
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td> 
</tr>
<tr>
    <td class='gauge-style text-center' >非正常损失</td>
    <td class='gauge-style text-left'>16</td>
    <td class ='tddata' colspan="3">
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td> 
</tr>
<tr>
    <td class='gauge-style text-center' >简易计税方法增税项目用</td>
    <td class='gauge-style text-left'>17</td>
    <td class ='tddata' colspan="3">
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td> 
</tr>
<tr>
    <td class='gauge-style text-center' >免抵退税办法不得抵扣的进项税额</td>
    <td class='gauge-style text-left'>18</td>
    <td class ='tddata' colspan="3">
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td> 
</tr>
<tr>
    <td class='gauge-style text-center' >纳税检查调减进项税额</td>
    <td class='gauge-style text-left'>19</td>
    <td class ='tddata' colspan="3">
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td> 
</tr>
<tr>
    <td class='gauge-style text-center' >红票专用发票通知单注明的进项税额</td>
    <td class='gauge-style text-left'>20</td>
    <td class ='tddata' colspan="3">
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td> 
</tr>
<tr>
    <td class='gauge-style text-center' >上期留抵税额</td>
    <td class='gauge-style text-left'>21</td>
    <td class ='tddata gray' colspan="3">
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td> 
</tr>
<tr>
    <td class='gauge-style text-center' >上期留抵税额</td>
    <td class='gauge-style text-left'>22</td>
    <td class ='tddata gray' colspan="3">
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td> 
</tr>
<tr>
    <td class='gauge-style text-center' >上期留抵税额</td>
    <td class='gauge-style text-left'>23</td>
    <td class ='tddata' colspan="3">
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td> 
</tr>
<tr>
    <td class='gauge-style text-center font-weight' colspan="5">三.待抵扣进项税额</td>
</tr>
<tr>
    <td class='gauge-style text-center' >项目</td>
    <td class='gauge-style text-center'>档次</td>
    <td class='gauge-style text-center'>税额</td>
    <td class='gauge-style text-center'>份数</td>
    <td class='gauge-style text-center'>金额</td>
</tr>
<tr>
    <td class='gauge-style text-left' >本期进项税转出额</td>
    <td class='gauge-style text-left'>24</td>
    <td class ='tddata gray'>
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
    </td> 
    <td class ='tddata gray'>
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
    </td>
    <td class ='tddata gray'>
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
    </td> 
</tr>
<tr>
    <td class='gauge-style text-left' >其中：免税项目</td>
    <td class='gauge-style text-left'>25</td>
    <td class ='tddata'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td> 
    <td class ='tddata'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
    <td class ='tddata'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td> 
</tr>
<tr>
    <td class='gauge-style text-center' >非应税项目用.集体福利.个人消费</td>
    <td class='gauge-style text-left'>26</td>
    <td class ='tddata'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td> 
    <td class ='tddata'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
    <td class ='tddata'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td> 
</tr>
<tr>
    <td class='gauge-style text-center' >非正常损失</td>
    <td class='gauge-style text-left'>27</td>
    <td class ='tddata'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td> 
    <td class ='tddata'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
    <td class ='tddata'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>  
</tr>
<tr>
    <td class='gauge-style text-center' >简易计税方法增税项目用</td>
    <td class='gauge-style text-left'>28</td>
    <td class ='tddata'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td> 
    <td class ='tddata'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
    <td class ='tddata'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td> 
</tr>
<tr>
    <td class='gauge-style text-center' >免抵退税办法不得抵扣的进项税额</td>
    <td class='gauge-style text-left'>29=30至33之和</td>
    <td class ='tddata gray'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td> 
    <td class ='tddata gray'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
    <td class ='tddata gray'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td> 
</tr>
<tr>
    <td class='gauge-style text-center' >纳税检查调减进项税额</td>
    <td class='gauge-style text-left'>30</td>
    <td class ='tddata'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td> 
    <td class ='tddata'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
    <td class ='tddata'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td> 
</tr>
<tr>
    <td class='gauge-style text-center' >红票专用发票通知单注明的进项税额</td>
    <td class='gauge-style text-left'>31</td>
    <td class ='tddata'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td> 
    <td class ='tddata'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
    <td class ='tddata'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td> 
</tr>
<tr>
    <td class='gauge-style text-center' >上期留抵税额</td>
    <td class='gauge-style text-left'>32</td>
    <td class ='tddata'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td> 
    <td class ='tddata gray'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
    <td class ='tddata'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td> 
</tr>
<tr>
    <td class='gauge-style text-center' >上期留抵税额</td>
    <td class='gauge-style text-left'>33</td>
    <td class ='tddata'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td> 
    <td class ='tddata'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
    <td class ='tddata'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td> 
</tr>
<tr>
    <td class='gauge-style text-center'></td>
    <td class='gauge-style text-left'>34</td>
    <td class='gauge-style text-center'></td>
    <td class='gauge-style text-center'></td>
    <td class='gauge-style text-center'></td>
</tr>
<tr>
    <td class='gauge-style text-center font-weight' colspan="5">四.其他</td>
</tr>
<tr>
    <td class='gauge-style text-center' >项目</td>
    <td class='gauge-style text-center'>档次</td>
    <td class='gauge-style text-center'>税额</td>
    <td class='gauge-style text-center'>份数</td>
    <td class='gauge-style text-center'>金额</td>
</tr>
<tr>
    <td class='gauge-style text-left' >本期进项税转出额</td>
    <td class='gauge-style text-left'>35</td>
    <td class ='tddata'>
        <div class='divimage'></div>
        <div class='divdata'>0</div>
    </td> 
    <td class ='tddata'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
    <td class ='tddata'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td> 
</tr>
<tr>
    <td class='gauge-style text-left' >其中：免税项目</td>
    <td class='gauge-style text-left'>36</td>
    <td class ='tddata gray'>
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
    </td> 
    <td class ='tddata gray'>
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
    </td>
    <td class ='tddata'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td> 
</tr>
</table>

		</div>
	</body>
	<script src="/12366/www.12366.ha.cn/Application/Home/Common/js/table.js"></script>
</html>