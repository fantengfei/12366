<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>
	<head>
		<title>html</title>
		<meta http-equiv="content-type" content="text/html charset=utf8">
		<link rel="stylesheet" type="text/css" href="/12366/www.12366.ha.cn/Application/Home/Common/css/table.css" media="all">
		<script src="/12366/www.12366.ha.cn/Application/Home/Common/js/jquery-1.4.3.min.js"></script>

        <script src="/12366/www.12366.ha.cn/Public/ext/ext-all.js"></script>
<!--<script src="/12366/www.12366.ha.cn/Public/ext/bootstrap.js"></script>-->
<script src="/12366/www.12366.ha.cn/Public/ext/packages/ext-locale/build/ext-locale-zh_CN.js"></script>
<link href="/12366/www.12366.ha.cn/Public/ext/packages/ext-theme-classic/build/resources/ext-theme-classic-all.css" rel="stylesheet" />
<!--<link href="/12366/www.12366.ha.cn/Public/ext/packages/ext-theme-neptune/build/resources/ext-theme-neptune-all.css" rel="stylesheet" />-->
<!--<link href="/12366/www.12366.ha.cn/Public/ext/packages/ext-theme-gray/build/resources/ext-theme-gray-all.css" rel="stylesheet" />-->
<script type="text/javascript">

    /**
     * 选项池，
     *
     * 标准字段有：‘保存，删除，打印预览，提取数据，修改本年累计’
     *
     * 应用范例：
     *
     * <\include file="./Application/Home/Common/html/toolbar.html" />
     * <\script type="text/javascript">
     *       Ext.onReady(function(){
     *           var option = ['保存','-' ,'删除'];
     *          createOptions(option);
     *       });
     * <\/script>
     *
     * */

    var option = [{
        xtype: 'button', // default for Toolbars
        text: '保存',
        icon: '/12366/www.12366.ha.cn/Application/Home/Common/icon/save-icon.png',
        listeners: {
            click: {
                fn: function() {
                    var table_data = Ext.get('bodydiv').getHtml();
                    var root_name  = $('#root_name').val();
                    var table_name = $('#table_name').val();
                    var table_type = $('#table_type').val();
                    var table_url  = $('#table_url').val();
                    Ext.Ajax.request({
                        url: '/12366/www.12366.ha.cn/index.php/Home/Index/save_table',
                        params: {
                            table_data:table_data,
                            root_name :root_name,
                            table_name:table_name,
                            table_type:table_type,
                            table_url :table_url
                        },
                        success: function(response){
                            var text = response.responseText;
                            if(text == 'success'){
                                alert("保存成功！");
                            }else{
                                alert("保存失败！");
                            }
                        }
                    });
                }
            }
        }
    },'-', {
        xtype: 'button',
        text : '删除',
        icon: '/12366/www.12366.ha.cn/Application/Home/Common/icon/return.png'
    },'-', {
        xtype:'button',
        text: '打印预览',
        icon: '/12366/www.12366.ha.cn/Application/Home/Common/icon/yulandayin.png'
    },'-', {
        xtype: 'button',
        text: '提取数据',
        icon:'/12366/www.12366.ha.cn/Application/Home/Common/icon/xuanzhuan.png'
    },'-',{
        xtype: 'checkbox',
        boxLabel: '修改本年累计'
    },'->', {
        xtype: 'button',
        icon: '/12366/www.12366.ha.cn/Application/Home/Common/icon/help.jpg'
    }];

    function createOptions(item) {

        var items = [];

        if (item == null) {
            items = option;
        } else {
            for (var j=0; j< item.length; j++) {
                if (item[j] == '-') {
                    items.push('-');
                    continue;
                }
                for (var i=0; i< option.length; i++) {
                    if (item[j] == option[i].text) {
                        items.push(option[i]);
                        break;
                    }
                }
            }
        }

        Ext.create('Ext.toolbar.Toolbar', {
            renderTo: 'tool-bar',
            border: false,
            items: items
        });
    }

    Ext.onReady(function(){

        // 设置 ‘bodydiv’ 元素的 style
        Ext.get('bodydiv').setHeight(document.documentElement.clientHeight - 28);
        Ext.fly('bodydiv').setStyle({
            border: 'solid 1px #000000',
            overflow:'auto'
        });
    });
</script>

        <script type="text/javascript">
            Ext.onReady(function(){
                createOptions();
            });
        </script>

		<style>
            .icon .divimage{
                background-image:url('/12366/www.12366.ha.cn/Application/Home/Common/image/trigon.png') ;
            }

		</style>
	</head>
	<body id="body-base">
        <div id="tool-bar"></div>
		<div id= 'bodydiv'>
            
<input type='hidden' id="table_url" value="<?php echo ($table_url); ?>">
<input type='hidden' id="root_name" value="增值税（一般纳税人使用）">
<input type='hidden' id="table_name" value="汇总纳税企业增值税分配表">
<input type='hidden' id="table_type" value="1">
<table id="bodytable" width="1032px;">
<tr class='titletr title-notic'>
    <td colspan = '9' id='titletd'>汇总纳税企业增值税分配表</td>
</tr>
<tr class='titletr title-notic'>
    <td colspan = '9' class='font-weight color-red'>（本期销售情况明细）</td>
</tr>
<tr class='titletr title-notic'>
    <td colspan = '9'>所属日期：</td>
</tr>
<tr>
    <td class='gauge-style text-left' style="height:28px;" colspan = '9'>汇总纳税企业增值税分配表-总机构信息</td>
</tr>
<tr>
    <td colspan="3" class='gauge-style text-right' style="height:28px;">
        总机构纳税人名称
    </td>
    <td class ='tddata gray' width='156px'>
        <div class='divimage'></div>
        <div class='divdata'></div>
    </td>
    <td class='gauge-style text-right' style="width:130px;">营业地址</td>
    <td class ='tddata' width='156px'>
        <div class='divimage'></div>
        <div class='divdata'></div>
    </td>
    <td class='gauge-style text-right' style="width:130px;">联系电话</td>
    <td colspan="2" class ='tddata'>
        <div class='divimage'></div>
        <div class='divdata'></div>
    </td>
</tr>
<tr>
    <td colspan="3" class='gauge-style text-right' style="height:28px;">
        法定代表人名称
    </td>
    <td class ='tddata gray'>
        <div class='divimage'></div>
        <div class='divdata'></div>
    </td>
    <td class='gauge-style text-right'>
        开户银行
    </td>
    <td class ='tddata' width='156px'>
        <div class='divimage'></div>
        <div class='divdata'></div>
    </td>
    <td class='gauge-style text-right'>
        银行账号
    </td>
    <td colspan="2" class ='tddata'>
        <div class='divimage'></div>
        <div class='divdata'></div>
    </td>
</tr>
<tr>
    <td colspan="3" class='gauge-style text-right' style="height:28px;">
        总机构纳税人识别号
    </td>
    <td class='gauge-style text-center'>
        应补（退）税额
    </td>
    <td class='gauge-style text-center'>
        总分机构销售额总计
    </td>
    <td class='gauge-style text-center'>
        总机构销售收入
    </td>
    <td class='gauge-style text-center'>
        比例分配
    </td>
    <td colspan="2" class='gauge-style text-center'>
        总机构分配税额
    </td>
    
</tr>
<tr>    
    <td colspan="3" class ='tddata gray' width='height:30px;'>
        <div class='divimage'></div>
        <div class='divdata'></div>
    </td>
    <td class ='tddata gray'>
        <div class='divimage'></div>
        <div class='divdata'></div>
    </td>
    <td class ='tddata gray'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
    <td class ='tddata'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
    <td class ='tddata'>
        <div class='divimage'></div>
        <div class='divdata'>100.000000%</div>
    </td>
    <td colspan="2" class ='tddata'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
</tr>
<tr>
    <td class='gauge-style text-left' style="height:28px;" colspan = '9'>分支机构情况</td>
</tr>
<tr>
    <td class='gauge-style text-center' style="width:53px;height:56px;">
        <input type='button' value='增加'>
        <input type='button' value='删除'>
    </td>
    <td class='gauge-style text-center' style='width:53px'>序列</td>
    <td class='gauge-style text-center' style='width:145px'>分支机构纳税人识别号</td>
    <td class='gauge-style text-center' >分支机构名称</td>
    <td class='gauge-style text-center' >分支机构销售收入</td>
     <td class='gauge-style text-center' >分支机构分配比例</td>
    <td class='gauge-style text-center' colspan="3">分支机构分配配额</td>
</tr>

<tr>
    <td class='gauge-style text-left' style="height:28px;" colspan = '9'>附加信息</td>
</tr>
<tr>
    <td class='gauge-style text-center bgcol-write' style="height:28px;" colspan = '3'>主管税务机关审核意见</td>
    <td class='gauge-style text-left bgcol-write' style="height:28px;" colspan = '9'></td>
</tr>
<tr>
    <td colspan="2" class='gauge-style text-center bgcol-write' style="height:30px;">报送单位</td>
    <td class='gauge-style text-center bgcol-write'></td>
    <td class='gauge-style text-center bgcol-write'>主管税务机关</td>
    <td class='gauge-style text-center bgcol-write'></td>
    <td class='gauge-style text-center bgcol-write'>受理人员</td>
    <td class='gauge-style text-center bgcol-write' ></td>
    <td class='gauge-style text-center bgcol-write' style='width:100px'>受理日期</td>
    <td class='gauge-style text-center bgcol-write' style='width:100px'></td>
</tr>
</table>

		</div>
	</body>
	<script src="/12366/www.12366.ha.cn/Application/Home/Common/js/table.js"></script>
</html>