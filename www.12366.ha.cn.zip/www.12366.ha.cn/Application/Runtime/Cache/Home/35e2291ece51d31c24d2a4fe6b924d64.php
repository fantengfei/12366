<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>
	<head>
		<title>html</title>
		<meta http-equiv="content-type" content="text/html charset=utf8">
		<link rel="stylesheet" type="text/css" href="/12366/www.12366.ha.cn/Application/Home/Common/css/table.css" media="all">
		<script src="/12366/www.12366.ha.cn/Application/Home/Common/js/jquery-1.4.3.min.js"></script>

        <script src="/12366/www.12366.ha.cn/Public/ext/ext-all.js"></script>
<!--<script src="/12366/www.12366.ha.cn/Public/ext/bootstrap.js"></script>-->
<script src="/12366/www.12366.ha.cn/Public/ext/packages/ext-locale/build/ext-locale-zh_CN.js"></script>
<link href="/12366/www.12366.ha.cn/Public/ext/packages/ext-theme-classic/build/resources/ext-theme-classic-all.css" rel="stylesheet" />
<!--<link href="/12366/www.12366.ha.cn/Public/ext/packages/ext-theme-neptune/build/resources/ext-theme-neptune-all.css" rel="stylesheet" />-->
<!--<link href="/12366/www.12366.ha.cn/Public/ext/packages/ext-theme-gray/build/resources/ext-theme-gray-all.css" rel="stylesheet" />-->
<script type="text/javascript">

    /**
     * 选项池，
     *
     * 标准字段有：‘保存，删除，打印预览，提取数据，修改本年累计’
     *
     * 应用范例：
     *
     * <\include file="./Application/Home/Common/html/toolbar.html" />
     * <\script type="text/javascript">
     *       Ext.onReady(function(){
     *           var option = ['保存','-' ,'删除'];
     *          createOptions(option);
     *       });
     * <\/script>
     *
     * */

    var option = [{
        xtype: 'button', // default for Toolbars
        text: '保存',
        icon: '/12366/www.12366.ha.cn/Application/Home/Common/icon/save-icon.png',
        listeners: {
            click: {
                fn: function() {
                    var table_data = Ext.get('bodydiv').getHtml();
                    var root_name  = $('#root_name').val();
                    var table_name = $('#table_name').val();
                    var table_type = $('#table_type').val();
                    var table_url  = $('#table_url').val();
                    Ext.Ajax.request({
                        url: '/12366/www.12366.ha.cn/index.php/Home/Index/save_table',
                        params: {
                            table_data:table_data,
                            root_name :root_name,
                            table_name:table_name,
                            table_type:table_type,
                            table_url :table_url
                        },
                        success: function(response){
                            var text = response.responseText;
                            if(text == 'success'){
                                alert("保存成功！");
                            }else{
                                alert("保存失败！");
                            }
                        }
                    });
                }
            }
        }
    },'-', {
        xtype: 'button',
        text : '删除',
        icon: '/12366/www.12366.ha.cn/Application/Home/Common/icon/return.png'
    },'-', {
        xtype:'button',
        text: '打印预览',
        icon: '/12366/www.12366.ha.cn/Application/Home/Common/icon/yulandayin.png'
    },'-', {
        xtype: 'button',
        text: '提取数据',
        icon:'/12366/www.12366.ha.cn/Application/Home/Common/icon/xuanzhuan.png'
    },'-',{
        xtype: 'checkbox',
        boxLabel: '修改本年累计'
    },'->', {
        xtype: 'button',
        icon: '/12366/www.12366.ha.cn/Application/Home/Common/icon/help.jpg'
    }];

    function createOptions(item) {

        var items = [];

        if (item == null) {
            items = option;
        } else {
            for (var j=0; j< item.length; j++) {
                if (item[j] == '-') {
                    items.push('-');
                    continue;
                }
                for (var i=0; i< option.length; i++) {
                    if (item[j] == option[i].text) {
                        items.push(option[i]);
                        break;
                    }
                }
            }
        }

        Ext.create('Ext.toolbar.Toolbar', {
            renderTo: 'tool-bar',
            border: false,
            items: items
        });
    }

    Ext.onReady(function(){

        // 设置 ‘bodydiv’ 元素的 style
        Ext.get('bodydiv').setHeight(document.documentElement.clientHeight - 28);
        Ext.fly('bodydiv').setStyle({
            border: 'solid 1px #000000',
            overflow:'auto'
        });
    });
</script>

        <script type="text/javascript">
            Ext.onReady(function(){
                createOptions();
            });
        </script>

		<style>
            .icon .divimage{
                background-image:url('/12366/www.12366.ha.cn/Application/Home/Common/image/trigon.png') ;
            }

		</style>
	</head>
	<body id="body-base">
        <div id="tool-bar"></div>
		<div id= 'bodydiv'>
            
<input type='hidden' id="table_url" value="<?php echo ($table_url); ?>">
<input type='hidden' id="root_name" value="增值税（一般纳税人使用）">
<input type='hidden' id="table_name" value="增值税纳税申请表（一般纳税人使用）">
<input type='hidden' id="table_type" value="1">
<table id="bodytable" width="943px;">
<tr class='titletr title-notic'>
    <td colspan = '7' id='titletd'>增值税纳税申请表（一般纳税人使用）</td>
</tr>
<tr class='titletr '>
    <td colspan = '7'>&nbsp;</td>
</tr>
<tr class='titletr title-notic'>
    <td colspan = '7'>根据国家税收法律法规及增值税相关规定制定本表。纳税人不论有无销售额，均应按税务机关规定的纳税期限填写本表，并向当地税务机关申报。</td>
</tr>
<tr class='titletr'>
    <td colspan = '3'>税款所属期：自2015年02月01日至2015年02月28日</td>
    <td colspan = '2'>填表日期：2015年03月06日</td>
    <td colspan = '2'>电话号码：13903730918</td>
</tr>
<tr class='titletr'>
    <td colspan = '3'>纳税人名称：河南起重机械有限公司</td>
    <td colspan = '2'>注册地址：新乡新长北线北侧</td>
    <td colspan = '2'>生产经营地址：新乡新长北线北侧</td>
</tr>
<tr class='titletr'>
    <td colspan = '3'>纳税人识别号：410711775106396</td>
    <td colspan = '2'>所属行业：轻小型起重设备制造</td>
    <td colspan = '2'>法定代表人：郭章先</td>
</tr>
<tr class='titletr'>
    <td colspan = '2'>开户银行：中国工商银行</td>
    <td colspan = '2'>银行账号：1704022419021023193</td>
    <td colspan = '2'>登记注册类型：其他有限责任公司</td>
    <td colspan = '1'>金额单位：元至角分</td>
</tr>
<tr>
    <td class='gauge-style text-center' colspan = '2' rowspan = '2'>项目</td>
    <td class='gauge-style text-center' rowspan = '2' style="width:110px;">栏次</td>
    <td class='gauge-style text-center' colspan = '2'>一般货物，劳务应税服务</td>
    <td class='gauge-style text-center' colspan = '2'>一般货物，劳务应税服务</td>
</tr>
<tr >
    <td class='gauge-style text-center' style="width:130px;">本月数</td>
    <td class='gauge-style text-center' style="width:130px;">本年统计</td>
    <td class='gauge-style text-center' style="width:130px;">本月数</td>
    <td class='gauge-style text-center' style="width:130px;">本年统计</td>
</tr>
<tr>
    <td class='gauge-style text-center' style="width:65px;" rowspan = '10'>销售额</td>
    <td class='gauge-style' style="width:220px;">（一）按使用税率计算销售额</td>
    <td class='gauge-style'>1</td>
    <td class ='tddata icon'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
    <td class ='tddata green'>
        <div class='divimage'></div>
        <div class='divdata'>13,505,080,88</div>
    </td>
    <td class ='tddata gray icon'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
    <td class ='tddata'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
</tr>
<tr>
    <td class='gauge-style' >其中：应税货物销售额</td>
    <td class='gauge-style' >2</td>
    <td class ='tddata'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
    <td class ='tddata green'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
    <td class ='tddata gray'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
    <td class ='tddata'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
</tr>
<tr>
    <td class='gauge-style' >应税劳务销售额</td>
    <td class='gauge-style' >3</td>
    <td class ='tddata'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
    <td class ='tddata green'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
    <td class ='tddata gray'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
    <td class ='tddata'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
</tr>
<tr>
    <td class='gauge-style' >纳税检查调整的销售额</td>
    <td class='gauge-style' >4</td>
    <td class ='tddata icon'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
    <td class ='tddata green'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
    <td class ='tddata gray'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
    <td class ='tddata'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
</tr>
<tr>
    <td class='gauge-style' >（二）按简易办法计税的销售额</td>
    <td class='gauge-style' >5</td>
    <td class ='tddata'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
    <td class ='tddata green'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
    <td class ='tddata gray'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
    <td class ='tddata'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
</tr>
<tr>
    <td class='gauge-style' >其中：纳税检查调整的销售额</td>
    <td class='gauge-style' >6</td>
    <td class ='tddata'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
    <td class ='tddata green'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
    <td class ='tddata gray'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
    <td class ='tddata'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
</tr>
<tr>
    <td class='gauge-style' >（三）免，抵，退办法出口销售额&nbsp; &nbsp; &nbsp;</td>
    <td class='gauge-style' >7</td>
    <td class ='tddata icon'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
    <td class ='tddata green'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
    <td class ='tddata gray'>
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
    </td>
    <td class ='tddata gray'>
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
    </td>
</tr>
<tr>
    <td class='gauge-style' >（四）免税销售额</td>
    <td class='gauge-style' >8</td>
    <td class ='tddata icon'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
    <td class ='tddata green'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
    <td class ='tddata gray'>
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
    </td>
    <td class ='tddata gray'>
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
    </td>
</tr>
<tr>
    <td class='gauge-style' >其中：免税货物销售额</td>
    <td class='gauge-style' >9</td>
    <td class ='tddata'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
    <td class ='tddata green'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
    <td class ='tddata gray'>
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
    </td>
    <td class ='tddata gray'>
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
    </td>
</tr>
<tr>
    <td class='gauge-style' >免税劳务销售额</td>
    <td class='gauge-style' >10</td>
    <td class ='tddata'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
    <td class ='tddata green'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
    <td class ='tddata gray'>
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
    </td>
    <td class ='tddata gray'>
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
    </td>
</tr>
<tr>
    <td class='gauge-style text-center' rowspan = '14'>税款计算</td>
    <td class='gauge-style' >销项税额</td>
    <td class='gauge-style' >11</td>
    <td class ='tddata icon'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
    <td class ='tddata green'>
        <div class='divimage'></div>
        <div class='divdata'>2,295,863,81</div>
    </td>
    <td class ='tddata gray icon'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
    <td class ='tddata green'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
</tr>
<tr>
    <td class='gauge-style' >进项税额</td>
    <td class='gauge-style' >12</td>
    <td class ='tddata icon'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
    <td class ='tddata green'>
        <div class='divimage'></div>
        <div class='divdata'>3,811,400,54</div>
    </td>
    <td class ='tddata gray'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
    <td class ='tddata green'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
</tr>
<tr>
    <td class='gauge-style' >上期留抵税款</td>
    <td class='gauge-style' >13</td>
    <td class ='tddata icon'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
    <td class ='tddata green icon'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
    <td class ='tddata gray icon'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
    <td class ='tddata gray'>
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
    </td>
</tr>
<tr>
    <td class='gauge-style' >进项税额转出</td>
    <td class='gauge-style' >14</td>
    <td class ='tddata icon'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
    <td class ='tddata green'>
        <div class='divimage'></div>
        <div class='divdata'>1,694,115,40</div>
    </td>
    <td class ='tddata gray'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
    <td class ='tddata green'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
</tr>
<tr>
    <td class='gauge-style' >免，抵，退应退税额</td>
    <td class='gauge-style' >15</td>
    <td class ='tddata'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
    <td class ='tddata green'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
    <td class ='tddata gray'>
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
    </td>
    <td class ='tddata gray'>
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
    </td>
</tr>
<tr>
    <td class='gauge-style' >按使用税率计算的纳税检查应补缴税额</td>
    <td class='gauge-style' >16</td>
    <td class ='tddata'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
    <td class ='tddata green'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
    <td class ='tddata gray'>
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
    </td>
    <td class ='tddata gray'>
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
    </td>
</tr>
<tr>
    <td class='gauge-style' >应抵扣税额合计</td>
    <td class='gauge-style' >17=12+13-14-15+16</td>
    <td class ='tddata gray'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
    <td class ='tddata gray'>
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
    </td>
    <td class ='tddata gray'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
    <td class ='tddata gray'>
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
    </td>
</tr>
<tr>
    <td class='gauge-style' >实际抵扣税额</td>
    <td class='gauge-style' >18（如17<11则为17，否则为11）</td>
    <td class ='tddata gray'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
    <td class ='tddata gray'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
    <td class ='tddata gray'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
    <td class ='tddata green'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
</tr>
<tr>
    <td class='gauge-style' >应纳税额</td>
    <td class='gauge-style' >19=11-18</td>
    <td class ='tddata gray'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
    <td class ='tddata green'>
        <div class='divimage'></div>
        <div class='divdata'>178,578,67</div>
    </td>
    <td class ='tddata gray'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
    <td class ='tddata green'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
</tr>
<tr>
    <td class='gauge-style' >期末留抵税额</td>
    <td class='gauge-style' >20=17-18</td>
    <td class ='tddata gray'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
    <td class ='tddata gray'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
    <td class ='tddata gray'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
    <td class ='tddata gray'>
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
    </td>
</tr>
<tr>
    <td class='gauge-style' >简易计算办法计算的应纳税额</td>
    <td class='gauge-style' >21</td>
    <td class ='tddata icon'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
    <td class ='tddata green'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
    <td class ='tddata gray icon'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
    <td class ='tddata green'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
</tr>
<tr>
    <td class='gauge-style' >按简易计算办法计算的纳税检查应补缴税额</td>
    <td class='gauge-style' >22</td>
    <td class ='tddata'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
    <td class ='tddata green'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
    <td class ='tddata gray'>
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
    </td>
    <td class ='tddata gray'>
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
    </td>
</tr>
<tr>
    <td class='gauge-style' >应纳税额减征额</td>
    <td class='gauge-style' >23</td>
    <td class ='tddata'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
    <td class ='tddata green'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
    <td class ='tddata gray'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
    <td class ='tddata green'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
</tr>
<tr>
    <td class='gauge-style' >应纳税额合计</td>
    <td class='gauge-style' >24=19+21-23</td>
    <td class ='tddata gray'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
    <td class ='tddata green'>
        <div class='divimage'></div>
        <div class='divdata'>178,578,67</div>
    </td>
    <td class ='tddata gray'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
    <td class ='tddata gray'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
</tr>
<tr>
    <td class='gauge-style text-center' rowspan = '14'>税款交纳</td>
    <td class='gauge-style' >期末未缴税额（多缴为负数）</td>
    <td class='gauge-style' >25</td>
    <td class ='tddata gray icon'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
    <td class ='tddata gray icon'>
        <div class='divimage'></div>
        <div class='divdata'>2,295,863,81</div>
    </td>
    <td class ='tddata gray icon'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
    <td class ='tddata gray icon'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
</tr>
<tr>
    <td class='gauge-style' >实收出口开具专用缴款书退税额</td>
    <td class='gauge-style' >26</td>
    <td class ='tddata gray'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
    <td class ='tddata green'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
    <td class ='tddata gray'>
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
    </td>
    <td class ='tddata green'>
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
    </td>
</tr>
<tr>
    <td class='gauge-style' >本期已缴税额</td>
    <td class='gauge-style' >27=28+29+30+31</td>
    <td class ='tddata gray'>
        <div class='divimage'></div>
        <div class='divdata'>178,578,67</div>
    </td>
    <td class ='tddata green'>
        <div class='divimage'></div>
        <div class='divdata'>531,385,38</div>
    </td>
    <td class ='tddata gray'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
    <td class ='tddata green'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
</tr>
<tr>
    <td class='gauge-style' >①分期预缴税额</td>
    <td class='gauge-style' >28</td>
    <td class ='tddata gray icon'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
    <td class ='tddata gray'>
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
    </td>
    <td class ='tddata gray'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
    <td class ='tddata gray'>
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
    </td>
</tr>
<tr>
    <td class='gauge-style' >②出口开具专用缴款书预缴税款</td>
    <td class='gauge-style' >29</td>
    <td class ='tddata icon'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
    <td class ='tddata gray'>
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
    </td>
    <td class ='tddata gray'>
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
    </td>
    <td class ='tddata gray'>
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
    </td>
</tr>
<tr>
    <td class='gauge-style' >③本期交纳上期应缴税额</td>
    <td class='gauge-style' >30</td>
    <td class ='tddata icon'>
        <div class='divimage'></div>
        <div class='divdata'>178,578,67</div>
    </td>
    <td class ='tddata green'>
        <div class='divimage'></div>
        <div class='divdata'>531,385,38</div>
    </td>
    <td class ='tddata gray'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
    <td class ='tddata green'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
</tr>
<tr>
    <td class='gauge-style' >④本期缴纳欠缴税额</td>
    <td class='gauge-style' >31</td>
    <td class ='tddata'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
    <td class ='tddata green'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
    <td class ='tddata gray'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
    <td class ='tddata green'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
</tr>
<tr>
    <td class='gauge-style' >期末未交税额（多缴为负数）</td>
    <td class='gauge-style' >32=24+25+26-27</td>
    <td class ='tddata gray'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
    <td class ='tddata gray'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
    <td class ='tddata gray'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
    <td class ='tddata gray'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
</tr>
<tr>
    <td class='gauge-style' >其中：欠缴税额（≥0）</td>
    <td class='gauge-style' >33=25+26-27</td>
    <td class ='tddata gray'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
    <td class ='tddata gray'>
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
    </td>
    <td class ='tddata gray'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
    <td class ='tddata gray'>
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
    </td>
</tr>
<tr>
    <td class='gauge-style' >本期应补（退）税额</td>
    <td class='gauge-style' >34=24-28-29</td>
    <td class ='tddata gray'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
    <td class ='tddata gray'>
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
    </td>
    <td class ='tddata gray'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
    <td class ='tddata gray'>
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
    </td>
</tr>
<tr>
    <td class='gauge-style' >即征即退实际退税额</td>
    <td class='gauge-style' >35</td>
    <td class ='tddata gray'>
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
    </td>
    <td class ='tddata gray'>
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
    </td>
    <td class ='tddata gray'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
    <td class ='tddata green'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
</tr>
<tr>
    <td class='gauge-style' >期初未交查补税额</td>
    <td class='gauge-style' >36</td>
    <td class ='tddata icon'>
        <div class='divimage'></div>
        <div class='divdata'>-14,704,27</div>
    </td>
    <td class ='tddata icon'>
        <div class='divimage'></div>
        <div class='divdata'>-14,704,27</div>
    </td>
    <td class ='tddata gray'>
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
    </td>
    <td class ='tddata gray'>
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
    </td>
</tr>
<tr>
    <td class='gauge-style' >本期入库查补税额</td>
    <td class='gauge-style' >37</td>
    <td class ='tddata'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
    <td class ='tddata green'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
    <td class ='tddata gray'>
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
    </td>
    <td class ='tddata gray'>
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
    </td>
</tr>
<tr>
    <td class='gauge-style' >期末未缴查补税额</td>
    <td class='gauge-style' >38=16+22+36-37</td>
    <td class ='tddata gray'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
    <td class ='tddata gray'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
    <td class ='tddata gray'>
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
    </td>
    <td class ='tddata gray'>
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
    </td>
</tr>

<tr class="trfoot" >
    <td rowspan = '6' class='text-center'>授权声明</td>
    <td rowspan = '5' colspan = '2' width= '300px' class='border-bottom-none'>如果你已委托代理人申报，请填写以下资料：为代理一切事宜，现授权：（地址）为本纳税人的代理申报人，任何与本申报表有关的往来文件，都可以寄予此人。</td>
    <td rowspan = '6' align="center" width= '130px'>声请人声明</td>
    <td rowspan = '5' class='border-bottom-none' width= '395px' colspan = '3'>&nbsp;&nbsp;本纳税生报表是根据国家税收法律法规即相关规定填报的，我确定它真实的，可靠地，完整的。</td>
</tr>
<tr class="trfoot"></tr>
<tr class="trfoot"></tr>
<tr class="trfoot"></tr>
<tr class="trfoot"></tr>

<tr>
    <td colspan = '2' class="input-align-right">授权人签字：</td>
    <td colspan = '3' class="input-align-right">声明人签字：</td>
</tr>

<tr class='trtdfoot'>
    <td colspan='3' >主管税务机关：</td>
    <td colspan='1' >接收人：</td>
    <td colspan='3' >接收日期：</td>
</tr>
</table>

		</div>
	</body>
	<script src="/12366/www.12366.ha.cn/Application/Home/Common/js/table.js"></script>
</html>