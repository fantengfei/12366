<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>
	<head>
		<title>html</title>
		<meta http-equiv="content-type" content="text/html charset=utf8">
		<link rel="stylesheet" type="text/css" href="/12366/www.12366.ha.cn/Application/Home/Common/css/table.css" media="all">
		<script src="/12366/www.12366.ha.cn/Application/Home/Common/js/jquery-1.4.3.min.js"></script>

        <script src="/12366/www.12366.ha.cn/Public/ext/ext-all.js"></script>
<!--<script src="/12366/www.12366.ha.cn/Public/ext/bootstrap.js"></script>-->
<script src="/12366/www.12366.ha.cn/Public/ext/packages/ext-locale/build/ext-locale-zh_CN.js"></script>
<link href="/12366/www.12366.ha.cn/Public/ext/packages/ext-theme-classic/build/resources/ext-theme-classic-all.css" rel="stylesheet" />
<!--<link href="/12366/www.12366.ha.cn/Public/ext/packages/ext-theme-neptune/build/resources/ext-theme-neptune-all.css" rel="stylesheet" />-->
<!--<link href="/12366/www.12366.ha.cn/Public/ext/packages/ext-theme-gray/build/resources/ext-theme-gray-all.css" rel="stylesheet" />-->
<script type="text/javascript">

    /**
     * 选项池，
     *
     * 标准字段有：‘保存，删除，打印预览，提取数据，修改本年累计’
     *
     * 应用范例：
     *
     * <\include file="./Application/Home/Common/html/toolbar.html" />
     * <\script type="text/javascript">
     *       Ext.onReady(function(){
     *           var option = ['保存','-' ,'删除'];
     *          createOptions(option);
     *       });
     * <\/script>
     *
     * */

    var option = [{
        xtype: 'button', // default for Toolbars
        text: '保存',
        icon: '/12366/www.12366.ha.cn/Application/Home/Common/icon/save-icon.png',
        listeners: {
            click: {
                fn: function() {
                    var table_data = Ext.get('bodydiv').getHtml();
                    var root_name  = $('#root_name').val();
                    var table_name = $('#table_name').val();
                    var table_type = $('#table_type').val();
                    var table_url  = $('#table_url').val();
                    Ext.Ajax.request({
                        url: '/12366/www.12366.ha.cn/index.php/Home/Index/save_table',
                        params: {
                            table_data:table_data,
                            root_name :root_name,
                            table_name:table_name,
                            table_type:table_type,
                            table_url :table_url
                        },
                        success: function(response){
                            var text = response.responseText;
                            if(text == 'success'){
                                alert("保存成功！");
                            }else{
                                alert("保存失败！");
                            }
                        }
                    });
                }
            }
        }
    },'-', {
        xtype: 'button',
        text : '删除',
        icon: '/12366/www.12366.ha.cn/Application/Home/Common/icon/return.png'
    },'-', {
        xtype:'button',
        text: '打印预览',
        icon: '/12366/www.12366.ha.cn/Application/Home/Common/icon/yulandayin.png'
    },'-', {
        xtype: 'button',
        text: '提取数据',
        icon:'/12366/www.12366.ha.cn/Application/Home/Common/icon/xuanzhuan.png'
    },'-',{
        xtype: 'checkbox',
        boxLabel: '修改本年累计'
    },'->', {
        xtype: 'button',
        icon: '/12366/www.12366.ha.cn/Application/Home/Common/icon/help.jpg'
    }];

    function createOptions(item) {

        var items = [];

        if (item == null) {
            items = option;
        } else {
            for (var j=0; j< item.length; j++) {
                if (item[j] == '-') {
                    items.push('-');
                    continue;
                }
                for (var i=0; i< option.length; i++) {
                    if (item[j] == option[i].text) {
                        items.push(option[i]);
                        break;
                    }
                }
            }
        }

        Ext.create('Ext.toolbar.Toolbar', {
            renderTo: 'tool-bar',
            border: false,
            items: items
        });
    }

    Ext.onReady(function(){

        // 设置 ‘bodydiv’ 元素的 style
        Ext.get('bodydiv').setHeight(document.documentElement.clientHeight - 28);
        Ext.fly('bodydiv').setStyle({
            border: 'solid 1px #000000',
            overflow:'auto'
        });
    });
</script>

        <script type="text/javascript">
            Ext.onReady(function(){
                createOptions();
            });
        </script>

		<style>
            .icon .divimage{
                background-image:url('/12366/www.12366.ha.cn/Application/Home/Common/image/trigon.png') ;
            }

		</style>
	</head>
	<body id="body-base">
        <div id="tool-bar"></div>
		<div id= 'bodydiv'>
            
<input type='hidden' id="table_url" value="<?php echo ($table_url); ?>">
<input type='hidden' id="root_name" value="增值税（一般纳税人使用）">
<input type='hidden' id="table_name" value="代扣代缴税通用缴款书抵扣清单">
<input type='hidden' id="table_type" value="1">
<table id="bodytable" width="955px;">
<tr class='titletr title-notic'>
    <td colspan = '11' id='titletd'>代扣代缴税通用缴款书抵扣清单</td>
</tr>
<tr class='titletr'>
    <td colspan = '3'>&nbsp;</td>
</tr>
<tr class='titletr'>
    <td colspan = '6'>纳税人识别号：410711775106396</td>
    <td colspan = '2' class='text-right'>纳税人名称：（公章）河南起重机械有限公司</td>
</tr>
<tr class='titletr'>
    <td colspan = '7'>税款所属期：自2015年02月01日至2015年02月28日</td>
    <td class='text-right'>金额单位：元至角至分</td>
</tr>
<tr>
    <td class='gauge-style text-center' style="width:53px;height:56px;">
        <input type='button' value='增加'>
        <input type='button' value='删除'>
    </td>
    <td class='gauge-style text-center' style='width:58px'>序列</td>
    <td class='gauge-style text-center' style='width:85px'>扣缴人纳税人识别号</td>
    <td class='gauge-style text-center' style="width:85px;">扣缴人名称</td>
    <td class='gauge-style text-center' style='width:85px'>征收机关名称</td>
    <td class='gauge-style text-center' style='width:85px'>代扣代缴项目</td>
    <td class='gauge-style text-center' style="width:85px;">代扣代缴凭证编号</td>
    <td class='gauge-style text-center' style='width:85px'>税额</td>
</tr>
<tr>
    <td class='gauge-style text-center' style="width:53px;height:28px;"></td>
    <td class='gauge-style text-center' style='width:58px'>合计</td>
    <td class ='tddata'>
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
    </td>
    <td class ='tddata'>
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
    </td>
    <td class ='tddata'>
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
    </td>
    <td class ='tddata'>
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
    </td>
    <td class ='tddata'>
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
    </td>
    <td class ='tddata gray'>
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
    </td>
</tr>
</table>

		</div>
	</body>
	<script src="/12366/www.12366.ha.cn/Application/Home/Common/js/table.js"></script>
</html>