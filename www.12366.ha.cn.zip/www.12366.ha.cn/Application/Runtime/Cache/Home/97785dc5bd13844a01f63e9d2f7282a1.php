<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>
	<head>
		<title>html</title>
		<meta http-equiv="content-type" content="text/html charset=utf8">
		<link rel="stylesheet" type="text/css" href="/12366/www.12366.ha.cn/Application/Home/Common/css/table.css" media="all">
		<script src="/12366/www.12366.ha.cn/Application/Home/Common/js/jquery-1.4.3.min.js"></script>

        <script src="/12366/www.12366.ha.cn/Public/ext/ext-all.js"></script>
<!--<script src="/12366/www.12366.ha.cn/Public/ext/bootstrap.js"></script>-->
<script src="/12366/www.12366.ha.cn/Public/ext/packages/ext-locale/build/ext-locale-zh_CN.js"></script>
<link href="/12366/www.12366.ha.cn/Public/ext/packages/ext-theme-classic/build/resources/ext-theme-classic-all.css" rel="stylesheet" />
<!--<link href="/12366/www.12366.ha.cn/Public/ext/packages/ext-theme-neptune/build/resources/ext-theme-neptune-all.css" rel="stylesheet" />-->
<!--<link href="/12366/www.12366.ha.cn/Public/ext/packages/ext-theme-gray/build/resources/ext-theme-gray-all.css" rel="stylesheet" />-->
<script type="text/javascript">

    /**
     * 选项池，
     *
     * 标准字段有：‘保存，删除，打印预览，提取数据，修改本年累计’
     *
     * 应用范例：
     *
     * <\include file="./Application/Home/Common/html/toolbar.html" />
     * <\script type="text/javascript">
     *       Ext.onReady(function(){
     *           var option = ['保存','-' ,'删除'];
     *          createOptions(option);
     *       });
     * <\/script>
     *
     * */

    var option = [{
        xtype: 'button', // default for Toolbars
        text: '保存',
        icon: '/12366/www.12366.ha.cn/Application/Home/Common/icon/save-icon.png',
        listeners: {
            click: {
                fn: function() {
                    alert(Ext.get('bodytable').getHtml());
                }
            }
        }
    },'-', {
        xtype: 'button',
        text : '删除',
        icon: '/12366/www.12366.ha.cn/Application/Home/Common/icon/return.png'
    },'-', {
        xtype:'button',
        text: '打印预览',
        icon: '/12366/www.12366.ha.cn/Application/Home/Common/icon/yulandayin.png'
    },'-', {
        xtype: 'button',
        text: '提取数据',
        icon:'/12366/www.12366.ha.cn/Application/Home/Common/icon/xuanzhuan.png'
    },'-',{
        xtype: 'checkbox',
        boxLabel: '修改本年累计'
    },'->', {
        xtype: 'button',
        icon: '/12366/www.12366.ha.cn/Application/Home/Common/icon/help.jpg'
    }];

    function createOptions(item) {

        var items = [];

        if (item == null) {
            items = option;
        } else {
            for (var j=0; j< item.length; j++) {
                if (item[j] == '-') {
                    items.push('-');
                    continue;
                }
                for (var i=0; i< option.length; i++) {
                    if (item[j] == option[i].text) {
                        items.push(option[i]);
                        break;
                    }
                }
            }
        }

        Ext.create('Ext.toolbar.Toolbar', {
            renderTo: 'tool-bar',
            border: false,
            items: items
        });
    }

    Ext.onReady(function(){

        // 设置 ‘bodydiv’ 元素的 style
        Ext.get('bodydiv').setHeight(document.documentElement.clientHeight - 28);
        Ext.fly('bodydiv').setStyle({
            border: 'solid 1px #000000',
            overflow:'auto'
        });
    });
</script>

        <script type="text/javascript">
            Ext.onReady(function(){
                createOptions();
            });
        </script>

		<style>
            .icon .divimage{
                background-image:url('/12366/www.12366.ha.cn/Application/Home/Common/image/trigon.png') ;
            }

		</style>
	</head>
	<body id="body-base">
        <div id="tool-bar"></div>
		<div id= 'bodydiv'>
                <table id="bodytable" width="900px;">        <tr class='titletr title-notic'>            <td colspan = '12' id='titletd'>购进农产品用于生产经营且不构成货物实体核定农产品增值税进项税额计算表</td>        </tr>        <tr class='title-notic titletr'>            <td colspan = '12' class="title-notic">&nbsp;</td>        </tr>        <tr class='titletr title-notic'>            <td class='titletr text-left' colspan = '5'>纳税人姓名：河南起重机器有限公司</td>            <td class='titletr text-left' colspan= "4">纳税人识别号：410711775106396</td>            <td class='titletr text-left' colspan="3">税款所属时间：2015年02月01日 至 2015年02月28日</td>        </tr>        <tr>            <td height="20px" width="50px" class="gauge-style text-center">操作</td>            <td width="40px" rowspan="3" class="gauge-style text-center">序列</td>            <td width="100px" rowspan="3" class="gauge-style text-center">产品名称</td>            <td width="100px" rowspan="3" class="gauge-style text-center">耗用农产品名称</td>            <td width="60px" rowspan="2" class="gauge-style text-center">当期耗用农产品数量（吨）</td>            <td width="60px" rowspan="2" class="gauge-style text-center">期初库存农产品数量（吨）</td>            <td width="60px" rowspan="2" class="gauge-style text-center">期初平均买价（元／吨）</td>            <td width="60px" rowspan="2" class="gauge-style text-center">当期购进农产品数量（吨）</td>            <td width="60px" rowspan="2" class="gauge-style text-center">当期买价（元／吨）</td>            <td width="100px" rowspan="2" class="gauge-style text-center">农产品平均购买单价（元／吨）</td>            <td width="60px" rowspan="2" class="gauge-style text-center">扣除率（13%）</td>            <td width="100px" rowspan="2" class="gauge-style text-center">当期允许抵扣农产品进项税额（元）</td>        </tr>        <tr>            <td height="20px" width="50px" class="gauge-style text-center">                <button>增加</button>            </td>        </tr>        <tr>            <td height="20px" width="50px" class="gauge-style text-center">                <button>删除</button>            </td>            <td height="20px" width="50px" class="gauge-style text-center">L1</td>            <td height="20px" width="50px" class="gauge-style text-center">L2</td>            <td height="20px" width="50px" class="gauge-style text-center">L3</td>            <td height="20px" width="50px" class="gauge-style text-center">L4</td>            <td height="20px" width="50px" class="gauge-style text-center">L5</td>            <td height="20px" width="50px" class="gauge-style text-center">L6=（L2+L3+L4+L5）／（L2+L4）</td>            <td height="20px" width="50px" class="gauge-style text-center">L7</td>            <td height="20px" width="50px" class="gauge-style text-center">L8＝L1*L6*L7／（1+L7）</td>        </tr>        <tr>            <td height="20px" width="50px" class="gauge-style text-center">合计</td>            <td height="20px" width="50px" class="gauge-style text-center">--</td>            <td height="20px" width="50px" class="gauge-style text-center">--</td>            <td height="20px" width="50px" class="gauge-style text-center">--</td>            <td height="20px" width="50px" class="gauge-style text-center">--</td>            <td height="20px" width="50px" class="gauge-style text-center">--</td>            <td height="20px" width="50px" class="gauge-style text-center">--</td>            <td height="20px" width="50px" class="gauge-style text-center">--</td>            <td height="20px" width="50px" class="gauge-style text-center">--</td>            <td height="20px" width="50px" class="tddata text-center gray">                <div class='divimage'></div>                <div class='divdata'>0.00</div>            </td>            <td height="20px" width="50px" class="gauge-style text-center">--</td>            <td height="20px" width="50px" class="gray text-center">                <div class='divimage'></div>                <div class='divdata'>0.00</div>            </td>        </tr>        <tr class='titletr'>            <td colspan = '12'>注：1. 购进农产品不构成货物实体的试点纳税人填列本表。</td>        </tr>        <tr class='titletr'>            <td colspan = '12'>&emsp;&emsp;2. 投入多种农产品原料生成一种或多种产品的，应分别不同产品和农产品原料填列本表。</td>        </tr>        <tr class='titletr'>            <td colspan = '12'>&emsp;&emsp;3. 各项数据均保留两位小数。</td>        </tr>    </table>
		</div>
	</body>
	<script src="/12366/www.12366.ha.cn/Application/Home/Common/js/table.js"></script>
</html>