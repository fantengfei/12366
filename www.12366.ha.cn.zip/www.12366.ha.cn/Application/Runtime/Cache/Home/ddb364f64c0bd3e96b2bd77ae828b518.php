<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>
	<head>
		<title>html</title>
		<meta http-equiv="content-type" content="text/html charset=utf8">
		<link rel="stylesheet" type="text/css" href="/12366/www.12366.ha.cn/Application/Home/Common/css/table.css" media="all">
		<script src="/12366/www.12366.ha.cn/Application/Home/Common/js/jquery-1.4.3.min.js"></script>

        <script src="/12366/www.12366.ha.cn/Public/ext/ext-all.js"></script>
<!--<script src="/12366/www.12366.ha.cn/Public/ext/bootstrap.js"></script>-->
<script src="/12366/www.12366.ha.cn/Public/ext/packages/ext-locale/build/ext-locale-zh_CN.js"></script>
<link href="/12366/www.12366.ha.cn/Public/ext/packages/ext-theme-classic/build/resources/ext-theme-classic-all.css" rel="stylesheet" />
<!--<link href="/12366/www.12366.ha.cn/Public/ext/packages/ext-theme-neptune/build/resources/ext-theme-neptune-all.css" rel="stylesheet" />-->
<!--<link href="/12366/www.12366.ha.cn/Public/ext/packages/ext-theme-gray/build/resources/ext-theme-gray-all.css" rel="stylesheet" />-->
<script type="text/javascript">

    /**
     * 选项池，
     *
     * 标准字段有：‘保存，删除，打印预览，提取数据，修改本年累计’
     *
     * 应用范例：
     *
     * <\include file="./Application/Home/Common/html/toolbar.html" />
     * <\script type="text/javascript">
     *       Ext.onReady(function(){
     *           var option = ['保存','-' ,'删除'];
     *          createOptions(option);
     *       });
     * <\/script>
     *
     * */

    var option = [{
        xtype: 'button', // default for Toolbars
        text: '保存',
        icon: '/12366/www.12366.ha.cn/Application/Home/Common/icon/save-icon.png',
        listeners: {
            click: {
                fn: function() {
                    var table_data = Ext.get('bodydiv').getHtml();
                    var root_name  = $('#root_name').val();
                    var table_name = $('#table_name').val();
                    var table_type = $('#table_type').val();
                    var table_url  = $('#table_url').val();
                    Ext.Ajax.request({
                        url: '/12366/www.12366.ha.cn/index.php/Home/Index/save_table',
                        params: {
                            table_data:table_data,
                            root_name :root_name,
                            table_name:table_name,
                            table_type:table_type,
                            table_url :table_url
                        },
                        success: function(response){
                            var text = response.responseText;
                            if(text == 'success'){
                                alert("保存成功！");
                            }else{
                                alert("保存失败！");
                            }
                        }
                    });
                }
            }
        }
    },'-', {
        xtype: 'button',
        text : '删除',
        icon: '/12366/www.12366.ha.cn/Application/Home/Common/icon/return.png'
    },'-', {
        xtype:'button',
        text: '打印预览',
        icon: '/12366/www.12366.ha.cn/Application/Home/Common/icon/yulandayin.png'
    },'-', {
        xtype: 'button',
        text: '提取数据',
        icon:'/12366/www.12366.ha.cn/Application/Home/Common/icon/xuanzhuan.png'
    },'-',{
        xtype: 'checkbox',
        boxLabel: '修改本年累计'
    },'->', {
        xtype: 'button',
        icon: '/12366/www.12366.ha.cn/Application/Home/Common/icon/help.jpg'
    }];

    function createOptions(item) {

        var items = [];

        if (item == null) {
            items = option;
        } else {
            for (var j=0; j< item.length; j++) {
                if (item[j] == '-') {
                    items.push('-');
                    continue;
                }
                for (var i=0; i< option.length; i++) {
                    if (item[j] == option[i].text) {
                        items.push(option[i]);
                        break;
                    }
                }
            }
        }

        Ext.create('Ext.toolbar.Toolbar', {
            renderTo: 'tool-bar',
            border: false,
            items: items
        });
    }

    Ext.onReady(function(){

        // 设置 ‘bodydiv’ 元素的 style
        Ext.get('bodydiv').setHeight(document.documentElement.clientHeight - 28);
        Ext.fly('bodydiv').setStyle({
            border: 'solid 1px #000000',
            overflow:'auto'
        });
    });
</script>

        <script type="text/javascript">
            Ext.onReady(function(){
                createOptions();
            });
        </script>

		<style>
            .icon .divimage{
                background-image:url('/12366/www.12366.ha.cn/Application/Home/Common/image/trigon.png') ;
            }

		</style>
	</head>
	<body id="body-base">
        <div id="tool-bar"></div>
		<div id= 'bodydiv'>
            
<input type='hidden' id="table_url" value="<?php echo ($table_url); ?>">
<input type='hidden' id="root_name" value="增值税（一般纳税人使用）">
<input type='hidden' id="table_name" value="增值税纳税申请表（一）">
<input type='hidden' id="table_type" value="1">
<table id="bodytable" width='2100px;'>
	<tr class='titletr title-notic'>
		<td colspan = '18' id='titletd'>增值税纳税申请表（一）</td>
	</tr>
	<tr class='titletr '>
		<td colspan = '18'>&nbsp;</td>
	</tr>
	<tr class='titletr title-notic'>
		<td colspan = '18' class='font-weight'>（本期销售情况明细）</td>
	</tr>
	<tr class='titletr'>
		<td colspan = '5'>税款所属期：自2015年02月01日至2015年02月28日</td>
		<td colspan = '4' class='color-red'>温馨提示：您是非营改增纳税人，可以填写：1,3,8,910,11,16,18</td>
	</tr>
	<tr class='titletr'>
		<td colspan = '17'>纳税人名称：（公章）河南起重机械有限公司</td>
		<td colspan = '2'>金额单位：元</td>
	</tr>
	<tr>
		<td class='gauge-style text-center' colspan = '4' rowspan = '3'>项目</td>
		<td class='gauge-style text-center' colspan = '2'>开具税控增值税专用发票 </td>
		<td class='gauge-style text-center' colspan = '2'>开具其他发票</td>
        <td class='gauge-style text-center' colspan = '2'>未开具其他发票</td>
        <td class='gauge-style text-center' colspan = '2'>纳税检查调整</td>
        <td class='gauge-style text-center' colspan = '3'>合计</td>
        <td class='gauge-style text-center' rowspan = '2'>服务扣除项目本期实际扣除金额</td>
        <td class='gauge-style text-center' colspan = '2'>扣除后</td>
	</tr>
	<tr >
		<td class='gauge-style text-center' >销售额</td>
		<td class='gauge-style text-center' >销项（应税）税额</td>
		<td class='gauge-style text-center' >销售额</td>
		<td class='gauge-style text-center' >销项（应税）税额</td>
        <td class='gauge-style text-center' >销售额</td>
        <td class='gauge-style text-center' >销项（应税）税额</td>
        <td class='gauge-style text-center' >销售额</td>
        <td class='gauge-style text-center' >销项（应税）税额</td>
        <td class='gauge-style text-center' >销售额</td>
        <td class='gauge-style text-center' >销项（应税）税额</td>
        <td class='gauge-style text-center' >价税合计</td>
        <td class='gauge-style text-center' >含税（免税）销售额</td>
        <td class='gauge-style text-center' >销项（应纳税额）</td>
	</tr>
    <tr >
        <td class='gauge-style text-center' width='120px'>1</td>
        <td class='gauge-style text-center' width='120px'>2</td>
        <td class='gauge-style text-center' width='120px'>3</td>
        <td class='gauge-style text-center' width='120px'>4</td>
        <td class='gauge-style text-center' width='120px'>5</td>
        <td class='gauge-style text-center' width='120px'>6</td>
        <td class='gauge-style text-center' width='120px'>7</td>
        <td class='gauge-style text-center' width='120px'>8</td>
        <td class='gauge-style text-center' width='120px'>9=1+3+5+7</td>
        <td class='gauge-style text-center' width='120px'>10=2+4+6+8</td>
        <td class='gauge-style text-center' width='120px'>11=9+10</td>
        <td class='gauge-style text-center' width='120px'>12</td>
        <td class='gauge-style text-center' width='120px'>13=11-12</td>
        <td class='gauge-style text-center' width='120px'>14=13/(100%+税率+征收率)*税率(征收率)</td>
    </tr>
    <tr>
        <td class='gauge-style text-center' width='32px' rowspan="7">一：一般计税方法计税</td>
        <td class='gauge-style text-center' width='42px' rowspan="5">全部征税项目</td>
        <td class='gauge-style gauge-styleLeft' width='199px'>17%征税的货物即加工修理修配劳务</td>
        <td class='gauge-style text-center' width='26px'>1</td>
        <td class='tddata ' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata' >
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
     </td>
        <td class='tddata' >
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
     </td>
        <td class='tddata' >
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
     </td>
        <td class='tddata' >
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
     </td>
    </tr>
    <tr>
        <td class='gauge-style gauge-styleLeft' >17%征税的货物即加工修理</td>
        <td class='gauge-style text-center' >2</td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
    </tr>
    <tr >

        <td class='gauge-style gauge-styleLeft' >17%征税的货物即加工修理</td>
        <td class='gauge-style text-center' >3</td>
        <td class='tddata' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
     </td>
    </tr>
    <tr >
 
        <td class='gauge-style gauge-styleLeft' >13%征税</td>
        <td class='gauge-style text-center' >4</td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
    </tr>
    <tr >

        <td class='gauge-style gauge-styleLeft' >17%征税</td>
        <td class='gauge-style text-center' >5</td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
    </tr>
    <tr >
    <td class='gauge-style text-center' rowspan="2">其中即征即退项目</td>
        <td class='gauge-style gauge-styleLeft' >即征即退货物及加工修理修配劳务</td>
        <td class='gauge-style text-center' >6</td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
     </td>
    </tr>
    <tr >
        <td class='gauge-style gauge-styleLeft' >即征即退应税服务</td>
        <td class='gauge-style text-center' >7</td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
    </tr>

        <tr>
        <td class='gauge-style text-center' width='32px' rowspan="10">二：简易计税方法计税</td>
        <td class='gauge-style text-center' width='42px' rowspan="8">全部征税项目</td>
        <td class='gauge-style gauge-styleLeft' width='199px'>17%征税的货物即加工修理修配劳务</td>
        <td class='gauge-style text-center' width='26px'>8</td>
        <td class='tddata' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
     </td>
    </tr>
    <tr >

        <td class='gauge-style gauge-styleLeft' >17%征税的货物即加工修理</td>
        <td class='gauge-style text-center' >9</td>
        <td class='tddata' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
     </td>
    </tr>
    <tr >

        <td class='gauge-style gauge-styleLeft' >17%征税的货物即加工修理</td>
        <td class='gauge-style text-center' >10</td>
        <td class='tddata' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
     </td>
    </tr>
    <tr >
 
        <td class='gauge-style gauge-styleLeft' >13%征税</td>
        <td class='gauge-style text-center' >11</td>
        <td class='tddata' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
     </td>
    </tr>
    <tr >

        <td class='gauge-style gauge-styleLeft' >17%征税</td>
        <td class='gauge-style text-center' >12</td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
    </tr>
    <tr >

        <td class='gauge-style gauge-styleLeft' >17%征税</td>
        <td class='gauge-style text-center' >13a</td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
    </tr>
    <tr >

        <td class='gauge-style gauge-styleLeft' >17%征税</td>
        <td class='gauge-style text-center' >13b</td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
    </tr>
    <tr >

        <td class='gauge-style gauge-styleLeft' >17%征税</td>
        <td class='gauge-style text-center' >13c</td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
    </tr>
    <tr >
    <td class='gauge-style text-center' rowspan="2">其中即征即退项目</td>
        <td class='gauge-style gauge-styleLeft' >即征即退货物及加工修理修配劳务</td>
        <td class='gauge-style text-center' >14</td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
     </td>
    </tr>
    <tr >
        <td class='gauge-style gauge-styleLeft' >即征即退应税服务</td>
        <td class='gauge-style text-center' >15</td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
    </tr>

    <tr >
	    <td class='gauge-style text-center' rowspan="2" >三：免抵退税</td>
	    <td class='gauge-style gauge-styleLeft' colspan="2">货物及加工修理修配服务</td>
        <td class='gauge-style text-center' >16</td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
     </td>
        <td class='tddata' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
     </td>
        <td class='tddata' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
     </td>
    </tr>
    <tr >
	    <td class='gauge-style gauge-styleLeft' colspan="2">应税服务</td>
        <td class='gauge-style text-center' >17</td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
     </td>
    </tr>
    <tr >
	    <td class='gauge-style text-center' rowspan="2">四：免税</td>
	    <td class='gauge-style gauge-styleLeft' colspan="2" >货物及加工修理修配服务</td>
        <td class='gauge-style text-center' >18</td>
        <td class='tddata' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
     </td>
        <td class='tddata' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
     </td>
    </tr>
    <tr >
	    <td class='gauge-style gauge-styleLeft' colspan="2">应税服务</td>
        <td class='gauge-style text-center' >19</td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata'>0.00</div>
     </td>
        <td class='tddata gray' >
        <div class='divimage'></div>
        <div class='divdata none-center'>--</div>
     </td>
    </tr>
</table>

		</div>
	</body>
	<script src="/12366/www.12366.ha.cn/Application/Home/Common/js/table.js"></script>
</html>