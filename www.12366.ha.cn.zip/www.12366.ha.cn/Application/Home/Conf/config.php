<?php
return array(
	//'配置项'=>'配置值'

    'TMPL_PARSE_STRING'  =>array (
        '__PUBLICS__' => __ROOT__.'/Public/Home',
        '__COMMON__' => __ROOT__.'/Application/Home/Common',
        '__ICON__' => __ROOT__.'/Application/Home/Common/icon',
        '__IMAGE__' => __ROOT__.'/Application/Home/Common/image',
        '__JS__' => __ROOT__.'/Application/Home/Common/js'
    )

);
?>